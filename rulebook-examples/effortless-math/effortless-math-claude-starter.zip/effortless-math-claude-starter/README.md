# Effortless Math — Claude Integration Handoff

This ZIP is a **starter and migration package**, not a finished pull request. It is designed to be placed in an `effortless-repos` workspace and given to Claude for full integration with the current `effortless-rulebooks` conventions.

## What is inside

```text
payload/effortless-math/
  canonical starter rulebook
  theorem catalog
  FLT flagship contract
  seven provider theorem stubs
  v21 source archive and selected artifacts
  schemas
  migration and trust documentation
  validation and staging scripts
```

The source architecture follows the current ERB principles:

- meaning lives in one canonical rulebook;
- all execution substrates are projections;
- conformance runs on every build;
- each example domain has its own rulebook and explicit `ERB_DOMAIN`;
- `rulebooktorulespeak` is required;
- `__meta__` is a first-class table;
- failures must be loud rather than silently routed to legacy paths or defaults.

## Recommended use

### Option A — standalone sibling repo, recommended

Create a new repository named `effortless-math`, copy the contents of `payload/effortless-math/` into its root, and have Claude connect it to the reusable ERB orchestration/substrate toolchain.

This best matches the long-term design: a theorem ecosystem with its own lifecycle, while reusing the same rulebook genome.

### Option B — temporary example-domain integration

Place this entire handoff folder somewhere in your workspace and run:

```bash
python payload/effortless-math/scripts/stage_as_rulebook_example.py /path/to/effortless-rulebooks
```

This stages the payload as:

```text
rulebook-examples/effortless-math/
```

The script refuses to overwrite an existing destination.

## Before Claude changes anything

Run:

```bash
cd payload/effortless-math
python scripts/validate_starter.py
```

Expected result:

```text
Theorems: 8
FLT provider dependencies: 7
v21 loops/proof facts/invariants: 571/113/305
v21 contradiction rows: 1
v21 active foundation kernels: 7
```

## What Claude should integrate

1. Read the host repo root `CLAUDE.md`.
2. Decide and document whether this is a standalone sibling repo or a temporary example domain.
3. Make `effortless-math-rulebook.json` conform to the current live rulebook schema without creating a parallel semantic registry.
4. Run a blank `effortless build`.
5. Reproduce the frozen v21 answer key in Postgres and every enabled substrate.
6. Add a generic provider-certificate resolver.
7. Keep FLT conditional on seven imported provider contracts.
8. Do not begin deep work on Chebotarev or another provider until the cross-domain rebuild and conformance loop is green.

## Do not let Claude do these things

- merge theorem-domain tables into the platform/admin rulebook;
- replace the rulebook with handwritten Python or SQL as the actual source of truth;
- silently skip unsupported tables or fields;
- mark providers fully internalized because their parent edge is represented;
- throw away the v21 archive or IDs;
- claim a complete independent proof of FLT;
- build a custom UI before the canonical theorem network passes conformance.

## Best first integration milestone

A new `effortless-math` domain/repo that can be deleted and rebuilt from the canonical rulebook while producing:

- the eight theorem catalog;
- the seven provider dependencies;
- all 571 loops;
- all 113 proof facts;
- all 305 invariant rows;
- one contradiction;
- the same proof statuses in Postgres, Python, RuleSpeak, OWL, and ExplainDAG.

See `CLAUDE_BOOTSTRAP_PROMPT.md` for a ready-to-paste instruction block.
