#!/usr/bin/env python3
import sqlite3,sys
from pathlib import Path
root=Path(__file__).resolve().parent
out=root/'fermat_witness_v21_rebuilt.sqlite'
if out.exists(): out.unlink()
con=sqlite3.connect(out)
con.executescript((root/'fermat_witness_v21_dump.sql').read_text())
fails=con.execute("select count(*) from invariant_checks where status='FAIL' or fail_count>0").fetchone()[0]
contr=con.execute("select count(*) from proof_trace where contradiction=1").fetchone()[0]
parents=con.execute("select count(*) from nine_parent_audit_v21 where parent_removed=1").fetchone()[0]
active=con.execute("select count(*) from import_surface where load_bearing=1").fetchone()[0]
kernels=con.execute("select count(*) from foundation_kernels_v21 where status='ACTIVE-FOUNDATION-KERNEL'").fetchone()[0]
print(f'Rebuilt: {out}')
print(f'Hard failures: {fails}')
print(f'Contradictions: {contr}')
print(f'Parents removed: {parents}')
print(f'Active imports: {active}')
print(f'Foundation kernels: {kernels}')
sys.exit(1 if fails or contr!=1 or parents!=9 or active!=7 or kernels!=7 else 0)
