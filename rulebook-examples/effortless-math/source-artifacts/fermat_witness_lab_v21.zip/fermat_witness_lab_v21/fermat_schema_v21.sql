CREATE TABLE a2_theta_coefficients_v20 (
  n INTEGER PRIMARY KEY,
  lattice_count INTEGER NOT NULL,
  divisor_formula INTEGER NOT NULL,
  coefficient_divisible_by_3 INTEGER NOT NULL,
  formula_pass INTEGER NOT NULL
);

CREATE TABLE a2_theta_modularity_certificates_v20 (
  certificate_id TEXT PRIMARY KEY,
  gram_matrix_json TEXT NOT NULL,
  rank INTEGER NOT NULL,
  determinant INTEGER NOT NULL,
  positive_definite INTEGER NOT NULL,
  even_lattice INTEGER NOT NULL,
  level INTEGER NOT NULL,
  nebentype TEXT NOT NULL,
  discriminant_group_order INTEGER NOT NULL,
  gauss_sum TEXT NOT NULL,
  milgram_identity_pass INTEGER NOT NULL,
  theta_modular_weight INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE additional_five_edge_plan_v19 (
  edge_order INTEGER PRIMARY KEY,
  edge_id TEXT NOT NULL,
  title TEXT NOT NULL,
  loop_start INTEGER NOT NULL,
  loop_end INTEGER NOT NULL,
  acceptance_criteria TEXT NOT NULL,
  result TEXT NOT NULL
);

CREATE TABLE adic_eigencharacter_stages_v9 (
  stage_id TEXT PRIMARY KEY,
  algebra_id TEXT NOT NULL,
  precision_n INTEGER NOT NULL,
  modulus INTEGER NOT NULL,
  generator_values_json TEXT NOT NULL,
  lifted_vector_json TEXT NOT NULL,
  transition_from_previous_pass INTEGER NOT NULL,
  simultaneous_eigenvector_pass INTEGER NOT NULL,
  FOREIGN KEY (algebra_id) REFERENCES localized_hecke_algebras_v9(algebra_id)
);

CREATE TABLE anti_invariant_cohomology_certificates_v12 (
  certificate_id TEXT PRIMARY KEY,
  locality_certificate_id TEXT NOT NULL,
  cocycle_certificate_id TEXT NOT NULL,
  involution_certificate_id TEXT NOT NULL,
  shapiro_certificate_id TEXT NOT NULL,
  coboundaries_in_plus INTEGER NOT NULL,
  minus_coboundary_rank INTEGER NOT NULL,
  minus_cocycle_projective INTEGER NOT NULL,
  minus_cohomology_free INTEGER NOT NULL,
  proof_rule TEXT NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE arithmetic_input_profiles_v12 (
  profile_id TEXT PRIMARY KEY,
  system_id TEXT NOT NULL,
  residual_prime INTEGER NOT NULL,
  stage_n INTEGER NOT NULL,
  deformation_problem_present INTEGER NOT NULL,
  local_conditions_present INTEGER NOT NULL,
  taylor_wiles_prime_conditions_present INTEGER NOT NULL,
  cohomology_rank_one_input_present INTEGER NOT NULL,
  hecke_galois_representation_input_present INTEGER NOT NULL,
  diamond_action_present INTEGER NOT NULL,
  augmentation_quotient_present INTEGER NOT NULL,
  generator_bound_present INTEGER NOT NULL,
  imported_input_count INTEGER NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE arithmetic_n_structure_obligations_v12 (
  obligation_id TEXT PRIMARY KEY,
  stage_order INTEGER NOT NULL,
  title TEXT NOT NULL,
  statement TEXT NOT NULL,
  status TEXT NOT NULL,
  witness_table TEXT,
  source_id TEXT,
  load_bearing INTEGER NOT NULL,
  exact_frontier TEXT NOT NULL
);

CREATE TABLE arithmetic_n_structure_runs_v12 (
  run_id TEXT PRIMARY KEY,
  profile_id TEXT NOT NULL,
  stage_freeness_derived INTEGER NOT NULL,
  diamond_augmentation_pass INTEGER NOT NULL,
  deformation_to_hecke_map_present INTEGER NOT NULL,
  generator_bound_pass INTEGER NOT NULL,
  stage_contract_satisfied INTEGER NOT NULL,
  n_structure_emitted INTEGER NOT NULL,
  direct_parent_import_used INTEGER NOT NULL,
  status TEXT NOT NULL,
  remaining_imports_json TEXT NOT NULL,
  FOREIGN KEY (profile_id) REFERENCES arithmetic_input_profiles_v12(profile_id)
);

CREATE TABLE arithmetic_parent_audit_v12 (
  edge_id TEXT PRIMARY KEY,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  assembler_internalized INTEGER NOT NULL,
  arithmetic_inputs_internalized INTEGER NOT NULL,
  parent_removed INTEGER NOT NULL,
  child_import_count INTEGER NOT NULL,
  status TEXT NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE artin_local_factor_certificates_v19 (
  certificate_id TEXT PRIMARY KEY,
  profile_id TEXT NOT NULL,
  frobenius_prime INTEGER NOT NULL,
  trace_value INTEGER NOT NULL,
  determinant_value INTEGER NOT NULL,
  artin_factor TEXT NOT NULL,
  modular_factor TEXT NOT NULL,
  factors_match INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE artin_local_factor_profiles_v10 (
  profile_id TEXT NOT NULL,
  frobenius_prime INTEGER NOT NULL,
  curve_trace INTEGER NOT NULL,
  determinant INTEGER NOT NULL,
  trace_mod3 INTEGER NOT NULL,
  determinant_mod3 INTEGER NOT NULL,
  local_factor_mod3 TEXT NOT NULL,
  form_coefficient INTEGER,
  trace_match INTEGER NOT NULL,
  PRIMARY KEY (profile_id,frobenius_prime)
);

CREATE TABLE artin_projective_type_profiles_v19 (
  profile_id TEXT PRIMARY KEY,
  projective_group TEXT NOT NULL,
  group_order INTEGER NOT NULL,
  solvable INTEGER NOT NULL,
  route TEXT NOT NULL,
  finite_image_lift_present INTEGER NOT NULL,
  odd INTEGER NOT NULL,
  local_factor_contract_present INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE automorphic_induction_state_machines_v19 (
  machine_id TEXT PRIMARY KEY,
  projective_type TEXT NOT NULL,
  step_count INTEGER NOT NULL,
  steps_json TEXT NOT NULL,
  internal_steps INTEGER NOT NULL,
  imported_steps INTEGER NOT NULL,
  terminal_weight_one_form INTEGER NOT NULL,
  direct_parent_import_used INTEGER NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE automorphy_kernel_contracts_v21 (
  certificate_id TEXT PRIMARY KEY,
  projective_type_count INTEGER NOT NULL,
  state_machine_count INTEGER NOT NULL,
  all_routes_terminate INTEGER NOT NULL,
  local_factor_count INTEGER NOT NULL,
  all_local_factors_match INTEGER NOT NULL,
  automorphy_kernel_input INTEGER NOT NULL,
  weight_one_parent_derived INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE basis_change_invariance_v14 (
 check_id TEXT PRIMARY KEY, stage_id TEXT NOT NULL, basis_change_json TEXT NOT NULL,
 determinant_unit INTEGER NOT NULL, conjugated_group_law_pass INTEGER NOT NULL,
 trace_invariance_pass INTEGER NOT NULL, determinant_invariance_pass INTEGER NOT NULL,
 pass INTEGER NOT NULL);

CREATE TABLE betti_etale_comparison_certificates_v15(certificate_id TEXT PRIMARY KEY,level_n INTEGER,residual_prime INTEGER,betti_dimension INTEGER,etale_rank INTEGER,plus_dimension INTEGER,minus_dimension INTEGER,hecke_generator_count INTEGER,hecke_eigenvalues_match INTEGER,pairing_rank_match INTEGER,finite_calibration_pass INTEGER,universal_comparison_status TEXT);

CREATE TABLE betti_etale_stage_certificates_v17 (
  certificate_id TEXT PRIMARY KEY,
  level_n INTEGER NOT NULL,
  residual_prime INTEGER NOT NULL,
  precision_n INTEGER NOT NULL,
  modulus INTEGER NOT NULL,
  genus INTEGER NOT NULL,
  betti_rank INTEGER NOT NULL,
  etale_rank INTEGER NOT NULL,
  comparison_hash TEXT NOT NULL,
  rank_match INTEGER NOT NULL,
  pairing_match INTEGER NOT NULL,
  transition_match INTEGER NOT NULL,
  geometric_input INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE branch_proof_traces(
 branch_name TEXT NOT NULL, step_no INTEGER NOT NULL, fact TEXT NOT NULL,
 derivation_kind TEXT NOT NULL, imported INTEGER NOT NULL, terminal INTEGER NOT NULL,
 PRIMARY KEY(branch_name,step_no));

CREATE TABLE brauer_lift_calibration_cases_v18 (
  case_id TEXT PRIMARY KEY,
  finite_group TEXT NOT NULL,
  residual_prime INTEGER NOT NULL,
  residual_character_json TEXT NOT NULL,
  ordinary_character_json TEXT NOT NULL,
  p_regular_restriction_match INTEGER NOT NULL,
  integral_lattice_present INTEGER NOT NULL,
  reduction_irreducible INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE brauer_nesbitt_compiler_cases_v17 (
  case_id TEXT PRIMARY KEY,
  candidate_character_json TEXT NOT NULL,
  recovered_decomposition_json TEXT NOT NULL,
  target_multiplicity INTEGER NOT NULL,
  other_multiplicity INTEGER NOT NULL,
  target_power INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE build_meta (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE cartier_duality_checks(check_id TEXT PRIMARY KEY,prime_p INTEGER,left_scheme TEXT,right_scheme TEXT,character_matrix_json TEXT,matrix_rank INTEGER,expected_rank INTEGER,perfect_pairing INTEGER,notes TEXT);

CREATE TABLE case_partitions_v12 (
  partition_id TEXT PRIMARY KEY,
  subject TEXT NOT NULL,
  predicate TEXT NOT NULL,
  positive_case TEXT NOT NULL,
  negative_case TEXT NOT NULL,
  mutually_exclusive INTEGER NOT NULL,
  exhaustive INTEGER NOT NULL,
  ordinary_branch_facts_asserted INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE cayley_hamilton_algebras_v13 (
  stage_id TEXT PRIMARY KEY,
  basis_rank INTEGER NOT NULL,
  structure_constants_json TEXT NOT NULL,
  associativity_failure_count INTEGER NOT NULL,
  unit_basis_index INTEGER NOT NULL,
  cayley_hamilton_quotient_pass INTEGER NOT NULL,
  structure_hash TEXT NOT NULL,
  FOREIGN KEY (stage_id) REFERENCES pseudocharacter_stages_v13(stage_id)
);

CREATE TABLE chain_ring_flatness_controls (
  control_id TEXT PRIMARY KEY,
  prime_p INTEGER NOT NULL,
  truncation_n INTEGER NOT NULL,
  ring_size INTEGER NOT NULL,
  module_rank INTEGER NOT NULL,
  module_size INTEGER NOT NULL,
  expected_free_size INTEGER NOT NULL,
  annihilator_size INTEGER NOT NULL,
  flat_control INTEGER NOT NULL,
  role TEXT NOT NULL
);

CREATE TABLE character_lattice_witnesses (
  model_id TEXT PRIMARY KEY,
  edge_labels_json TEXT NOT NULL,
  degree_zero_basis_json TEXT NOT NULL,
  lattice_rank INTEGER NOT NULL,
  expected_rank INTEGER NOT NULL,
  basis_saturated INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  source_id TEXT,
  FOREIGN KEY (model_id) REFERENCES modular_integral_models(model_id)
);

CREATE TABLE chebotarev_density_obligations_v19 (
  obligation_id TEXT PRIMARY KEY,
  stage_order INTEGER NOT NULL,
  title TEXT NOT NULL,
  statement TEXT NOT NULL,
  status TEXT NOT NULL,
  witness_table TEXT,
  source_id TEXT,
  exact_frontier TEXT NOT NULL
);

CREATE TABLE chebotarev_parent_audit_v19 (
  edge_id TEXT PRIMARY KEY,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  finite_quotient_compiler_internalized INTEGER NOT NULL,
  analytic_density_internalized INTEGER NOT NULL,
  parent_removed INTEGER NOT NULL,
  child_import_count INTEGER NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE cohomology_action_stages_v14 (
 stage_id TEXT PRIMARY KEY, source_stage_id TEXT NOT NULL, prime_p INTEGER NOT NULL,
 precision_n INTEGER NOT NULL, modulus INTEGER NOT NULL, module_rank INTEGER NOT NULL,
 hecke_scalar_action INTEGER NOT NULL, group_element_count INTEGER NOT NULL,
 group_law_pass INTEGER NOT NULL, hecke_galois_commutation_pass INTEGER NOT NULL,
 finite_continuity_pass INTEGER NOT NULL, pass INTEGER NOT NULL);

CREATE TABLE comparison_kernel_certificates_v21 (
  certificate_id TEXT PRIMARY KEY,
  good_stage_count INTEGER NOT NULL,
  bad_stage_count INTEGER NOT NULL,
  all_betti_etale_stages_pass INTEGER NOT NULL,
  all_hecke_squares_pass INTEGER NOT NULL,
  all_eichler_shimura_stages_pass INTEGER NOT NULL,
  all_monodromy_models_pass INTEGER NOT NULL,
  comparison_kernel_input INTEGER NOT NULL,
  good_comparison_derived INTEGER NOT NULL,
  nearby_cycles_derived INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE component_group_toys(toy_id TEXT PRIMARY KEY,presentation_matrix_json TEXT,smith_diagonal_json TEXT,finite_order INTEGER,residual_prime INTEGER,p_torsion_dimension INTEGER,component_group_vanishes_after_localization INTEGER,interpretation TEXT);

CREATE TABLE component_primary_profiles_v6 (
  certificate_id TEXT NOT NULL,
  residual_prime INTEGER NOT NULL,
  component_group_order INTEGER NOT NULL,
  valuation_at_residual_prime INTEGER NOT NULL,
  primary_order INTEGER NOT NULL,
  p_torsion_dimension INTEGER NOT NULL,
  obstruction_group_zero INTEGER NOT NULL,
  PRIMARY KEY (certificate_id,residual_prime),
  FOREIGN KEY (certificate_id) REFERENCES raynaud_component_certificates_v6(certificate_id)
);

CREATE TABLE conditional_branch_certificates_v12 (
  certificate_id TEXT PRIMARY KEY,
  partition_id TEXT NOT NULL,
  branch_condition TEXT NOT NULL,
  conclusion TEXT NOT NULL,
  antecedent_obligations_json TEXT NOT NULL,
  imported_obligations_json TEXT NOT NULL,
  conditional_not_realized_fact INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  FOREIGN KEY (partition_id) REFERENCES case_partitions_v12(partition_id)
);

CREATE TABLE conjugation_split_certificates_v8 (
  certificate_id TEXT PRIMARY KEY,
  level_n INTEGER NOT NULL,
  residual_prime INTEGER NOT NULL,
  cuspidal_dimension INTEGER NOT NULL,
  star_square_identity INTEGER NOT NULL,
  plus_dimension INTEGER NOT NULL,
  minus_dimension INTEGER NOT NULL,
  expected_each_dimension INTEGER NOT NULL,
  split_pass INTEGER NOT NULL,
  matrix_hash TEXT NOT NULL
);

CREATE TABLE connected_etale_dimension_models_v16 (
  model_id TEXT PRIMARY KEY,
  target_irrep_dimension INTEGER NOT NULL,
  target_connected_dimension INTEGER NOT NULL,
  multiplicity INTEGER NOT NULL,
  total_module_dimension INTEGER NOT NULL,
  connected_dimension INTEGER NOT NULL,
  dimension_ratio INTEGER NOT NULL,
  cardinality_match INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE constituent_control_certificates_v17 (
  certificate_id TEXT PRIMARY KEY,
  profile_id TEXT NOT NULL,
  residual_prime INTEGER NOT NULL,
  residual_irreducible INTEGER NOT NULL,
  all_classes_covered INTEGER NOT NULL,
  character_compiler_pass INTEGER NOT NULL,
  constituent_power_derived INTEGER NOT NULL,
  direct_parent_import_used INTEGER NOT NULL,
  status TEXT NOT NULL,
  remaining_imports_json TEXT NOT NULL
);

CREATE TABLE constituent_decomposition_certificates_v16 (
  certificate_id TEXT PRIMARY KEY,
  model_id TEXT NOT NULL,
  frobenius_trace_contract TEXT NOT NULL,
  chebotarev_contract TEXT NOT NULL,
  brauer_nesbitt_contract TEXT NOT NULL,
  residual_irreducibility INTEGER NOT NULL,
  semisimplification_is_target_power INTEGER NOT NULL,
  multiplicity INTEGER NOT NULL,
  dimension INTEGER NOT NULL,
  universal_status TEXT NOT NULL,
  pass INTEGER NOT NULL,
  FOREIGN KEY (model_id) REFERENCES finite_character_models_v16(model_id)
);

CREATE TABLE counterfactual_builds (
  build_id TEXT PRIMARY KEY,
  disabled_rules_json TEXT NOT NULL,
  derived_fact_count INTEGER NOT NULL,
  contradiction_derived INTEGER NOT NULL,
  terminal_facts_json TEXT NOT NULL,
  interpretation TEXT NOT NULL
);

CREATE TABLE counterfactual_component_tests_v6 (
  test_id TEXT PRIMARY KEY,
  node_weight_sum INTEGER NOT NULL,
  residual_prime INTEGER NOT NULL,
  predicted_component_group_order INTEGER NOT NULL,
  predicted_p_primary_order INTEGER NOT NULL,
  predicted_obstruction_zero INTEGER NOT NULL,
  expected_obstruction_zero INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  interpretation TEXT NOT NULL
);

CREATE TABLE crt_specialization_certificates_v19 (
  certificate_id TEXT PRIMARY KEY,
  profile_id TEXT NOT NULL,
  moduli_json TEXT NOT NULL,
  residues_json TEXT NOT NULL,
  crt_base_solution INTEGER NOT NULL,
  combined_modulus INTEGER NOT NULL,
  selected_parameter INTEGER NOT NULL,
  local_constraints_pass INTEGER NOT NULL,
  bad_polynomials_nonzero INTEGER NOT NULL,
  universal_hilbert_input INTEGER NOT NULL,
  auxiliary_curve_selected INTEGER NOT NULL,
  direct_parent_import_used INTEGER NOT NULL,
  status TEXT NOT NULL,
  FOREIGN KEY (profile_id) REFERENCES thin_set_profiles_v19(profile_id)
);

CREATE TABLE curve_form_matches (
  curve_id TEXT NOT NULL,
  form_id TEXT NOT NULL,
  prime_q INTEGER NOT NULL,
  curve_trace INTEGER NOT NULL,
  form_coefficient INTEGER NOT NULL,
  exact_match INTEGER NOT NULL,
  PRIMARY KEY (curve_id, form_id, prime_q),
  FOREIGN KEY (curve_id) REFERENCES elliptic_curve_models(curve_id),
  FOREIGN KEY (form_id) REFERENCES eta_quotient_witnesses(form_id)
);

CREATE TABLE cusp_eisenstein_checks_v7 (
  check_id TEXT PRIMARY KEY,
  level_m INTEGER NOT NULL,
  hecke_prime_r INTEGER NOT NULL,
  r_congruent_1_mod_m INTEGER NOT NULL,
  double_coset_representative_count INTEGER NOT NULL,
  expected_count INTEGER NOT NULL,
  boundary_hecke_eigenvalue INTEGER NOT NULL,
  eisenstein_relation_zero INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  source_id TEXT
);

CREATE TABLE cyclic_extension_cocycles (
  cocycle_id TEXT PRIMARY KEY,
  prime_p INTEGER NOT NULL,
  class_c INTEGER NOT NULL,
  group_order INTEGER NOT NULL,
  cocycle_table_json TEXT NOT NULL,
  cocycle_condition_pass INTEGER NOT NULL,
  coboundary INTEGER NOT NULL,
  extension_split INTEGER NOT NULL,
  upper_triangular_generator_json TEXT NOT NULL,
  generator_order INTEGER NOT NULL,
  inertia_trivial INTEGER NOT NULL
);

CREATE TABLE cyclic_isogeny_degree_ledger_v19 (
  degree_n INTEGER PRIMARY KEY,
  allowed_over_q INTEGER NOT NULL,
  prime_factorization_json TEXT NOT NULL,
  used_in_frey_argument INTEGER NOT NULL,
  route TEXT NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE deformation_problem_contracts_v10 (
  problem_id TEXT PRIMARY KEY,
  residual_prime INTEGER NOT NULL,
  representation_dimension INTEGER NOT NULL,
  determinant_condition TEXT NOT NULL,
  ramification_set_json TEXT NOT NULL,
  local_conditions_json TEXT NOT NULL,
  coefficient_category TEXT NOT NULL,
  absolute_irreducibility_required INTEGER NOT NULL,
  representability_status TEXT NOT NULL,
  universal_ring_symbol TEXT NOT NULL,
  hecke_algebra_symbol TEXT NOT NULL
);

CREATE TABLE deformation_ring_toys(
 ring_id TEXT PRIMARY KEY, presentation TEXT NOT NULL, characteristic INTEGER NOT NULL,
 tangent_dimension INTEGER NOT NULL, relation_count INTEGER NOT NULL,
 vector_space_length INTEGER, complete_intersection INTEGER NOT NULL,
 calculation_pass INTEGER NOT NULL, role TEXT NOT NULL, notes TEXT);

CREATE TABLE deformation_universal_property_certificates_v12 (
  certificate_id TEXT PRIMARY KEY,
  residual_prime INTEGER NOT NULL,
  universal_ring TEXT NOT NULL,
  target_ring TEXT NOT NULL,
  residual_representation_match INTEGER NOT NULL,
  determinant_condition_match INTEGER NOT NULL,
  local_conditions_match INTEGER NOT NULL,
  unique_map_constructed INTEGER NOT NULL,
  map_description_json TEXT NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE degeneracy_map_certificates_v7 (
  map_id TEXT PRIMARY KEY,
  base_level_n INTEGER NOT NULL,
  raised_level_nq INTEGER NOT NULL,
  removed_prime_q INTEGER NOT NULL,
  residual_prime INTEGER NOT NULL,
  source_cuspidal_dimension INTEGER NOT NULL,
  target_single_dimension INTEGER NOT NULL,
  target_double_dimension INTEGER NOT NULL,
  relation_count INTEGER NOT NULL,
  relation_failure_count INTEGER NOT NULL,
  boundary_failure_count INTEGER NOT NULL,
  combined_rank INTEGER NOT NULL,
  cokernel_dimension INTEGER NOT NULL,
  surjective INTEGER NOT NULL,
  residual_equals_removed_prime INTEGER NOT NULL,
  non_eisenstein_gate INTEGER,
  status TEXT NOT NULL,
  matrix_hash TEXT NOT NULL
);

CREATE TABLE degeneracy_matrix_entries_v7 (
  map_id TEXT NOT NULL,
  row_index INTEGER NOT NULL,
  column_index INTEGER NOT NULL,
  value INTEGER NOT NULL,
  PRIMARY KEY (map_id,row_index,column_index),
  FOREIGN KEY (map_id) REFERENCES degeneracy_map_certificates_v7(map_id)
);

CREATE TABLE degeneracy_operator_cases(case_id TEXT PRIMARY KEY,residual_prime INTEGER,auxiliary_prime_q INTEGER,hecke_trace_tq INTEGER,matrix_json TEXT,determinant INTEGER,determinant_mod_p INTEGER,kernel_dimension_mod_p INTEGER,level_condition TEXT,pass INTEGER);

CREATE TABLE degeneracy_specialization_adapters (
  adapter_id TEXT PRIMARY KEY,
  source_level INTEGER NOT NULL,
  target_level INTEGER NOT NULL,
  residual_prime INTEGER NOT NULL,
  removed_prime_q INTEGER NOT NULL,
  composition_matrix_json TEXT NOT NULL,
  composition_kernel_basis_json TEXT NOT NULL,
  character_lattice_model_id TEXT,
  specialization_matrix_json TEXT,
  pairing_compatibility_pass INTEGER NOT NULL,
  finite_adapter_pass INTEGER NOT NULL,
  geometric_identification_status TEXT NOT NULL,
  source_id TEXT
);

CREATE TABLE degeneracy_specialization_checks (
  check_id TEXT PRIMARY KEY,
  residual_prime INTEGER NOT NULL,
  degeneracy_matrix_json TEXT NOT NULL,
  degeneracy_kernel_basis_json TEXT NOT NULL,
  component_relation_matrix_json TEXT NOT NULL,
  specialized_vectors_json TEXT NOT NULL,
  surviving_dimension INTEGER NOT NULL,
  expected_dimension INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  role TEXT NOT NULL
);

CREATE TABLE dependency_audit (
  rule_id TEXT PRIMARY KEY,
  rule_kind TEXT NOT NULL,
  imported INTEGER NOT NULL,
  source_id TEXT,
  contradiction_with_rule INTEGER NOT NULL,
  contradiction_without_rule INTEGER NOT NULL,
  individually_load_bearing INTEGER NOT NULL,
  notes TEXT
);

CREATE TABLE diamond_augmentation_certificates_v12 (
  certificate_id TEXT PRIMARY KEY,
  residual_prime INTEGER NOT NULL,
  stage_n INTEGER NOT NULL,
  delta_rank INTEGER NOT NULL,
  delta_orders_json TEXT NOT NULL,
  group_ring_presentation TEXT NOT NULL,
  diamond_map_json TEXT NOT NULL,
  augmentation_map_json TEXT NOT NULL,
  augmentation_composite_identity INTEGER NOT NULL,
  augmentation_kernel_generator_count INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE dual_graph_witnesses_v5 (
  model_id TEXT PRIMARY KEY,
  vertex_count INTEGER NOT NULL,
  edge_count INTEGER NOT NULL,
  incidence_matrix_json TEXT NOT NULL,
  connected INTEGER NOT NULL,
  cycle_rank INTEGER NOT NULL,
  expected_cycle_rank INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  FOREIGN KEY (model_id) REFERENCES modular_integral_models(model_id)
);

CREATE TABLE dual_selmer_kill_runs(run_id TEXT PRIMARY KEY,prime_p INTEGER,initial_dimension INTEGER,evaluation_matrix_json TEXT,evaluation_rank INTEGER,remaining_dimension INTEGER,selected_primes_json TEXT,all_selected_are_taylor_wiles INTEGER,killed INTEGER);

CREATE TABLE edge_closure_audit_v6 (
  edge_id TEXT PRIMARY KEY,
  edge_scope TEXT NOT NULL,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  child_obligations INTEGER NOT NULL,
  internally_witnessed_children INTEGER NOT NULL,
  source_backed_children INTEGER NOT NULL,
  unresolved_children INTEGER NOT NULL,
  main_trace_closed INTEGER NOT NULL,
  calibration_closed INTEGER NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE edge_closure_audit_v7 (
  edge_id TEXT PRIMARY KEY,
  edge_scope TEXT NOT NULL,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  child_obligations INTEGER NOT NULL,
  internally_witnessed_children INTEGER NOT NULL,
  source_backed_children INTEGER NOT NULL,
  unresolved_children INTEGER NOT NULL,
  main_trace_closed INTEGER NOT NULL,
  calibration_closed INTEGER NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE edge_closure_audit_v8 (
  edge_id TEXT PRIMARY KEY,
  edge_scope TEXT NOT NULL,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  child_obligations INTEGER NOT NULL,
  internally_witnessed_children INTEGER NOT NULL,
  source_backed_children INTEGER NOT NULL,
  unresolved_children INTEGER NOT NULL,
  main_trace_closed INTEGER NOT NULL,
  calibration_closed INTEGER NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE edge_closure_audit_v9 (
  edge_id TEXT PRIMARY KEY,
  edge_scope TEXT NOT NULL,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  child_obligations INTEGER NOT NULL,
  internally_witnessed_children INTEGER NOT NULL,
  source_backed_children INTEGER NOT NULL,
  unresolved_children INTEGER NOT NULL,
  main_trace_closed INTEGER NOT NULL,
  calibration_closed INTEGER NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE edge_reduction_audit_v12 (
  edge_id TEXT PRIMARY KEY,
  edge_scope TEXT NOT NULL,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  internal_children INTEGER NOT NULL,
  imported_children INTEGER NOT NULL,
  unresolved_children INTEGER NOT NULL,
  direct_parent_import_removed INTEGER NOT NULL,
  theorem_content_fully_internalized INTEGER NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE edge_reduction_audit_v5 (
  edge_id TEXT PRIMARY KEY,
  parent_import TEXT NOT NULL,
  child_obligations INTEGER NOT NULL,
  internally_witnessed_children INTEGER NOT NULL,
  source_backed_children INTEGER NOT NULL,
  unresolved_children INTEGER NOT NULL,
  main_trace_load_bearing INTEGER NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE eichler_shimura_stage_certificates_v15(certificate_id TEXT PRIMARY KEY,profile_id TEXT,residual_prime INTEGER,precision_n INTEGER,modulus INTEGER,frobenius_prime INTEGER,trace_value INTEGER,determinant_value INTEGER,frobenius_matrix_json TEXT,characteristic_polynomial TEXT,relation_failure_count INTEGER,commutes_with_hecke INTEGER,pass INTEGER);

CREATE TABLE eigenclass_lift_controls (
  check_id TEXT PRIMARY KEY,
  residual_prime INTEGER NOT NULL,
  hecke_operators_json TEXT NOT NULL,
  common_eigenvector_json TEXT NOT NULL,
  eigenvalues_json TEXT NOT NULL,
  quotient_relation_matrix_json TEXT NOT NULL,
  survives_quotient INTEGER NOT NULL,
  lifts_to_integral INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  role TEXT NOT NULL
);

CREATE TABLE eigenpacket_hensel_lifts (
  lift_id TEXT PRIMARY KEY,
  residual_prime INTEGER NOT NULL,
  operator_label TEXT NOT NULL,
  polynomial TEXT NOT NULL,
  root_mod_p INTEGER NOT NULL,
  derivative_mod_p INTEGER NOT NULL,
  precision_n INTEGER NOT NULL,
  lifted_root INTEGER NOT NULL,
  modulus INTEGER NOT NULL,
  polynomial_zero_modulus INTEGER NOT NULL,
  unique_simple_lift INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE eisenstein_congruence_stages_v18 (
  stage_id TEXT PRIMARY KEY,
  residual_prime INTEGER NOT NULL,
  coefficient_count INTEGER NOT NULL,
  weight_one_coefficients_json TEXT NOT NULL,
  eisenstein_coefficients_json TEXT NOT NULL,
  product_coefficients_json TEXT NOT NULL,
  congruence_mod_p INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE elliptic_curve_models (
  curve_id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  a1 INTEGER NOT NULL,
  a2 INTEGER NOT NULL,
  a3 INTEGER NOT NULL,
  a4 INTEGER NOT NULL,
  a6 INTEGER NOT NULL,
  c4 TEXT NOT NULL,
  c6 TEXT NOT NULL,
  discriminant TEXT NOT NULL,
  conductor INTEGER NOT NULL,
  conductor_derivation TEXT NOT NULL,
  role TEXT NOT NULL,
  source_id TEXT,
  FOREIGN KEY (source_id) REFERENCES sources(source_id)
);

CREATE TABLE equation_cases (
  case_id TEXT PRIMARY KEY,
  a INTEGER NOT NULL,
  b INTEGER NOT NULL,
  c INTEGER NOT NULL,
  exponent INTEGER NOT NULL,
  equation_holds INTEGER NOT NULL,
  nontrivial INTEGER NOT NULL,
  gcd_abc INTEGER NOT NULL,
  primitive INTEGER NOT NULL,
  role TEXT NOT NULL,
  notes TEXT
);

CREATE TABLE eta_product_coefficients (
  form_id TEXT NOT NULL,
  n INTEGER NOT NULL,
  coefficient INTEGER NOT NULL,
  PRIMARY KEY (form_id, n),
  FOREIGN KEY (form_id) REFERENCES eta_quotient_witnesses(form_id)
);

CREATE TABLE eta_quotient_witnesses (
  form_id TEXT PRIMARY KEY,
  level_n INTEGER NOT NULL,
  exponents_json TEXT NOT NULL,
  weight INTEGER NOT NULL,
  q_shift INTEGER NOT NULL,
  sum_delta_r_delta INTEGER NOT NULL,
  sum_n_over_delta_r_delta INTEGER NOT NULL,
  square_character_product TEXT NOT NULL,
  cusp_order_infinity TEXT NOT NULL,
  cusp_order_zero TEXT NOT NULL,
  criterion_pass INTEGER NOT NULL,
  theorem_status TEXT NOT NULL,
  source_id TEXT,
  notes TEXT,
  FOREIGN KEY (source_id) REFERENCES sources(source_id)
);

CREATE TABLE etale_rank_counterfactuals_v15(test_id TEXT PRIMARY KEY,changed_or_missing_hypothesis TEXT,generic_rank INTEGER,fiber_dimension INTEGER,o_torsion_free INTEGER,two_invertible INTEGER,residual_plus_dimension INTEGER,residual_minus_dimension INTEGER,rank_two_compiler_accept INTEGER,sign_rank_one_compiler_accept INTEGER,expected_rank_two_accept INTEGER,expected_sign_accept INTEGER,pass INTEGER,interpretation TEXT);

CREATE TABLE etale_rank_obligations_v15(obligation_id TEXT PRIMARY KEY,stage_order INTEGER,title TEXT,statement TEXT,status TEXT,witness_table TEXT,source_id TEXT,load_bearing INTEGER,exact_frontier TEXT);

CREATE TABLE explicit_lift_certificates_v9 (
  certificate_id TEXT PRIMARY KEY,
  lowering_certificate_id TEXT NOT NULL,
  target_form_id TEXT NOT NULL,
  rank_one_lift_certificate_id TEXT NOT NULL,
  target_level INTEGER NOT NULL,
  residual_prime INTEGER NOT NULL,
  target_sturm_bound INTEGER NOT NULL,
  sturm_checks_pass INTEGER NOT NULL,
  integral_eigenform_present INTEGER NOT NULL,
  characteristic_zero_lift_derived INTEGER NOT NULL,
  lifting_edge_closed INTEGER NOT NULL,
  remaining_lifting_imports_json TEXT NOT NULL,
  upstream_dependencies_json TEXT NOT NULL,
  status TEXT NOT NULL,
  FOREIGN KEY (rank_one_lift_certificate_id) REFERENCES rank_one_lift_certificates_v9(certificate_id)
);

CREATE TABLE extension_exactness_checks (
  check_id TEXT PRIMARY KEY,
  prime_p INTEGER NOT NULL,
  cocycle_id TEXT NOT NULL,
  extension_elements INTEGER NOT NULL,
  kernel_size INTEGER NOT NULL,
  quotient_size INTEGER NOT NULL,
  expected_kernel_size INTEGER NOT NULL,
  expected_quotient_size INTEGER NOT NULL,
  exactness_pass INTEGER NOT NULL,
  FOREIGN KEY (cocycle_id) REFERENCES cyclic_extension_cocycles(cocycle_id)
);

CREATE TABLE faithful_module_isomorphism_certificates_v20 (
  certificate_id TEXT PRIMARY KEY,
  residual_prime INTEGER NOT NULL,
  source_ring TEXT NOT NULL,
  target_ring TEXT NOT NULL,
  map_surjective INTEGER NOT NULL,
  module_free_over_source INTEGER NOT NULL,
  module_rank INTEGER NOT NULL,
  source_action_factors_through_target INTEGER NOT NULL,
  annihilator_zero INTEGER NOT NULL,
  kernel_annihilates_module INTEGER NOT NULL,
  kernel_zero INTEGER NOT NULL,
  map_isomorphism INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE final_nine_counterfactuals_v21 (
  test_id TEXT PRIMARY KEY,
  kernel_scope TEXT NOT NULL,
  changed_input TEXT NOT NULL,
  parent_fact_derived INTEGER NOT NULL,
  expected_derived INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  interpretation TEXT NOT NULL
);

CREATE TABLE final_nine_plan_v21 (
  edge_order INTEGER PRIMARY KEY,
  edge_id TEXT NOT NULL,
  title TEXT NOT NULL,
  loop_start INTEGER NOT NULL,
  loop_end INTEGER NOT NULL,
  parent_removed INTEGER NOT NULL,
  replacement_kernel_id TEXT NOT NULL,
  result TEXT NOT NULL
);

CREATE TABLE final_work_schedule_v9 (
  package_id TEXT PRIMARY KEY,
  sequence_no INTEGER NOT NULL,
  planned_loop_start INTEGER NOT NULL,
  planned_loop_end INTEGER NOT NULL,
  title TEXT NOT NULL,
  scope TEXT NOT NULL,
  acceptance_criteria TEXT NOT NULL,
  status TEXT NOT NULL,
  dependencies_json TEXT NOT NULL,
  notes TEXT
);

CREATE TABLE finite_character_models_v16 (
  model_id TEXT PRIMARY KEY,
  field_characteristic INTEGER NOT NULL,
  group_name TEXT NOT NULL,
  terms_json TEXT NOT NULL,
  character_values_json TEXT NOT NULL,
  recovered_multiplicities_json TEXT NOT NULL,
  target_irrep TEXT NOT NULL,
  target_multiplicity INTEGER NOT NULL,
  all_constituents_target INTEGER NOT NULL,
  total_dimension INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE finite_flat_boundary_profiles (
  profile_id TEXT PRIMARY KEY,
  prime_p INTEGER NOT NULL,
  valuation_v INTEGER NOT NULL,
  valuation_mod_p INTEGER NOT NULL,
  generic_extension_split INTEGER NOT NULL,
  endpoints_finite_flat INTEGER NOT NULL,
  middle_extension_constructed INTEGER NOT NULL,
  finite_flat_conclusion INTEGER,
  status TEXT NOT NULL,
  source_id TEXT,
  exact_missing_inference TEXT NOT NULL
);

CREATE TABLE finite_flat_classification_parent_audit_v20 (
  edge_id TEXT PRIMARY KEY,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  explicit_middle_extension_internalized INTEGER NOT NULL,
  converse_valuation_internalized INTEGER NOT NULL,
  parent_removed INTEGER NOT NULL,
  child_import_count INTEGER NOT NULL,
  theorem_content_fully_internalized_for_scope INTEGER NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE finite_flat_compiler_runs_v17 (
  run_id TEXT PRIMARY KEY,
  residual_prime INTEGER NOT NULL,
  valuation INTEGER NOT NULL,
  valuation_mod_p INTEGER NOT NULL,
  unit_kummer_class INTEGER NOT NULL,
  endpoint_models_present INTEGER NOT NULL,
  generic_exact_sequence_present INTEGER NOT NULL,
  classification_input INTEGER NOT NULL,
  finite_flat_derived INTEGER NOT NULL,
  direct_parent_import_used INTEGER NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE finite_flat_extension_obligations(obligation_id TEXT PRIMARY KEY,statement TEXT,antecedent_witnessed INTEGER,algebra_model_present INTEGER,general_proof_present INTEGER,status TEXT,source_id TEXT,exact_frontier TEXT);

CREATE TABLE finite_flat_local_contracts_v14 (
 contract_id TEXT PRIMARY KEY, residual_prime INTEGER NOT NULL, a_p INTEGER NOT NULL,
 ordinary_unit_root_exists INTEGER NOT NULL, ordinary_compiler_accept INTEGER NOT NULL,
 finite_flat_route_required INTEGER NOT NULL, status TEXT NOT NULL, exact_frontier TEXT NOT NULL);

CREATE TABLE finite_galois_class_profiles_v19 (
  profile_id TEXT PRIMARY KEY,
  polynomial TEXT NOT NULL,
  galois_group TEXT NOT NULL,
  group_order INTEGER NOT NULL,
  class_name TEXT NOT NULL,
  class_size INTEGER NOT NULL,
  expected_density TEXT NOT NULL,
  representative_prime INTEGER NOT NULL,
  class_table_complete INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE finite_group_models_v13 (
  group_id TEXT PRIMARY KEY,
  group_name TEXT NOT NULL,
  group_order INTEGER NOT NULL,
  elements_json TEXT NOT NULL,
  multiplication_table_json TEXT NOT NULL,
  inverse_table_json TEXT NOT NULL,
  table_hash TEXT NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE finite_group_witnesses(
 witness_id TEXT PRIMARY KEY, object_name TEXT NOT NULL, order_value INTEGER NOT NULL,
 structure_claim TEXT NOT NULL, computation_json TEXT NOT NULL,
 pass INTEGER NOT NULL);

CREATE TABLE finite_trace_rt_stages_v10 (
  calibration_id TEXT NOT NULL,
  residual_prime INTEGER NOT NULL,
  precision_n INTEGER NOT NULL,
  modulus INTEGER NOT NULL,
  frobenius_primes_json TEXT NOT NULL,
  trace_values_json TEXT NOT NULL,
  hecke_values_json TEXT NOT NULL,
  determinant_values_json TEXT NOT NULL,
  trace_match INTEGER NOT NULL,
  ring_map_is_identity INTEGER NOT NULL,
  PRIMARY KEY (calibration_id,precision_n)
);

CREATE TABLE first_second_case_routes(
 route_id TEXT PRIMARY KEY, exponent_p INTEGER NOT NULL, case_name TEXT NOT NULL,
 p_divides_abc INTEGER NOT NULL, reduction_at_p TEXT NOT NULL,
 local_status_at_p TEXT NOT NULL, imported_edge_required INTEGER NOT NULL,
 route_complete INTEGER NOT NULL, notes TEXT);

CREATE TABLE five_edge_audit_v17 (
  edge_order INTEGER PRIMARY KEY,
  edge_id TEXT NOT NULL,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  parent_removed INTEGER NOT NULL,
  internal_children INTEGER NOT NULL,
  imported_children INTEGER NOT NULL,
  theorem_content_fully_internalized INTEGER NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE five_edge_audit_v19 (
  edge_order INTEGER PRIMARY KEY,
  edge_id TEXT NOT NULL,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  parent_removed INTEGER NOT NULL,
  internal_children INTEGER NOT NULL,
  imported_children INTEGER NOT NULL,
  theorem_content_fully_internalized INTEGER NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE five_edge_counterfactuals_v17 (
  test_id TEXT PRIMARY KEY,
  edge_scope TEXT NOT NULL,
  changed_input TEXT NOT NULL,
  parent_derived INTEGER NOT NULL,
  expected_derived INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  interpretation TEXT NOT NULL
);

CREATE TABLE five_edge_counterfactuals_v19 (
  test_id TEXT PRIMARY KEY,
  edge_scope TEXT NOT NULL,
  changed_input TEXT NOT NULL,
  parent_derived INTEGER NOT NULL,
  expected_derived INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  interpretation TEXT NOT NULL
);

CREATE TABLE five_edge_plan_v17 (
  edge_order INTEGER PRIMARY KEY,
  edge_id TEXT NOT NULL,
  title TEXT NOT NULL,
  loop_start INTEGER NOT NULL,
  loop_end INTEGER NOT NULL,
  acceptance_criteria TEXT NOT NULL,
  result TEXT NOT NULL
);

CREATE TABLE five_import_audit_v20 (
  edge_order INTEGER PRIMARY KEY,
  edge_id TEXT NOT NULL,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  parent_removed INTEGER NOT NULL,
  internal_children INTEGER NOT NULL,
  reused_active_children INTEGER NOT NULL,
  new_imported_children INTEGER NOT NULL,
  theorem_content_fully_internalized_for_scope INTEGER NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE five_import_counterfactuals_v20 (
  test_id TEXT PRIMARY KEY,
  edge_scope TEXT NOT NULL,
  changed_input TEXT NOT NULL,
  parent_derived INTEGER NOT NULL,
  expected_derived INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  interpretation TEXT NOT NULL
);

CREATE TABLE five_import_plan_v20 (
  edge_order INTEGER PRIMARY KEY,
  edge_id TEXT NOT NULL,
  title TEXT NOT NULL,
  loop_start INTEGER NOT NULL,
  loop_end INTEGER NOT NULL,
  acceptance_criteria TEXT NOT NULL,
  result TEXT NOT NULL
);

CREATE TABLE fong_swan_parent_audit_v18 (
  edge_id TEXT PRIMARY KEY,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  finite_image_compiler_internalized INTEGER NOT NULL,
  parent_removed INTEGER NOT NULL,
  child_import_count INTEGER NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE formal_flt_profiles (
  profile_id TEXT PRIMARY KEY,
  exponent_p INTEGER NOT NULL,
  a_factorization_json TEXT NOT NULL,
  b_factorization_json TEXT NOT NULL,
  c_factorization_json TEXT NOT NULL,
  initial_conductor TEXT NOT NULL,
  minimal_discriminant_valuation_rule TEXT NOT NULL,
  odd_primes_all_finite INTEGER NOT NULL,
  prime_2_nonfinite INTEGER NOT NULL,
  epistemic_tier TEXT NOT NULL,
  notes TEXT
);

CREATE TABLE formal_immersion_contracts_v21 (
  certificate_id TEXT PRIMARY KEY,
  modular_curve_count INTEGER NOT NULL,
  tangent_certificate_count INTEGER NOT NULL,
  all_tangent_ranks_pass INTEGER NOT NULL,
  cyclic_degree_ledger_complete INTEGER NOT NULL,
  frey_local_profiles_pass INTEGER NOT NULL,
  formal_immersion_kernel_input INTEGER NOT NULL,
  isogeny_parent_derived INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE formal_immersion_tangent_certificates_v19 (
  certificate_id TEXT PRIMARY KEY,
  level_n INTEGER NOT NULL,
  cusp_label TEXT NOT NULL,
  differential_count INTEGER NOT NULL,
  leading_coefficient_matrix_json TEXT NOT NULL,
  tangent_rank INTEGER NOT NULL,
  expected_rank INTEGER NOT NULL,
  rank_zero_quotient_input INTEGER NOT NULL,
  formal_immersion_child_input INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE formal_local_profiles (
  profile_id TEXT NOT NULL,
  prime_q INTEGER NOT NULL,
  source_component TEXT NOT NULL,
  base_valuation INTEGER NOT NULL,
  minimal_delta_valuation INTEGER NOT NULL,
  valuation_mod_p INTEGER NOT NULL,
  representation_finite INTEGER NOT NULL,
  removable_by_level_lowering INTEGER NOT NULL,
  anchor_nonfinite_prime INTEGER NOT NULL,
  PRIMARY KEY (profile_id, prime_q),
  FOREIGN KEY (profile_id) REFERENCES formal_flt_profiles(profile_id)
);

CREATE TABLE foundation_kernels_v21 (
  kernel_order INTEGER PRIMARY KEY,
  kernel_id TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  mathematical_scope TEXT NOT NULL,
  input_contract_json TEXT NOT NULL,
  output_contract_json TEXT NOT NULL,
  finite_compiler_tables_json TEXT NOT NULL,
  source_id TEXT NOT NULL,
  theorem_content_internalized INTEGER NOT NULL,
  status TEXT NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE free_group_cocycle_certificates_v12 (
  certificate_id TEXT PRIMARY KEY,
  prime_p INTEGER NOT NULL,
  generator_count INTEGER NOT NULL,
  module_dimension INTEGER NOT NULL,
  word_count INTEGER NOT NULL,
  tested_pairs INTEGER NOT NULL,
  exhaustive INTEGER NOT NULL,
  cocycle_failures INTEGER NOT NULL,
  z1_free_rank INTEGER NOT NULL,
  generator_values_hash TEXT NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE frey_local_parent_audit_v19 (
  edge_id TEXT PRIMARY KEY,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  local_profiles_internalized INTEGER NOT NULL,
  shared_formal_immersion_child INTEGER NOT NULL,
  parent_removed INTEGER NOT NULL,
  child_import_count INTEGER NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE frey_local_specialization_profiles_v19 (
  profile_id TEXT PRIMARY KEY,
  residual_prime INTEGER NOT NULL,
  cyclic_isogeny_degree INTEGER NOT NULL,
  parity_normalized INTEGER NOT NULL,
  semistable INTEGER NOT NULL,
  full_rational_2_torsion INTEGER NOT NULL,
  local_specialization_is_cusp INTEGER NOT NULL,
  formal_immersion_input INTEGER NOT NULL,
  rational_point_forced_cusp INTEGER NOT NULL,
  noncuspidal_frey_point INTEGER NOT NULL,
  contradiction_derived INTEGER NOT NULL,
  direct_parent_import_used INTEGER NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE frey_prime_case_partitions_v18 (
  partition_id TEXT PRIMARY KEY,
  small_case TEXT NOT NULL,
  p11_case TEXT NOT NULL,
  large_case TEXT NOT NULL,
  mutually_exclusive INTEGER NOT NULL,
  exhaustive_for_p_ge5 INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE frey_samples (
  sample_id TEXT PRIMARY KEY,
  a INTEGER NOT NULL,
  b INTEGER NOT NULL,
  p INTEGER NOT NULL,
  gcd_ab INTEGER NOT NULL,
  opposite_parity INTEGER NOT NULL,
  a_power TEXT NOT NULL,
  b_power TEXT NOT NULL,
  c_power_sum TEXT NOT NULL,
  c_power_is_perfect_pth INTEGER NOT NULL,
  c_root TEXT,
  curve_equation TEXT NOT NULL,
  discriminant TEXT NOT NULL,
  c4 TEXT NOT NULL,
  c6 TEXT NOT NULL,
  j_numerator TEXT NOT NULL,
  j_denominator TEXT NOT NULL,
  invariant_identity_pass INTEGER NOT NULL,
  notes TEXT
);

CREATE TABLE frey_small_prime_profiles_v18 (
  profile_id TEXT PRIMARY KEY,
  residual_prime INTEGER NOT NULL,
  full_rational_2_torsion INTEGER NOT NULL,
  rational_p_isogeny_would_give_2p INTEGER NOT NULL,
  induced_degree INTEGER NOT NULL,
  degree_classification_excludes INTEGER NOT NULL,
  local_frey_obstruction_input INTEGER NOT NULL,
  irreducible_derived INTEGER NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE frobenius_irreducibility_certificates(
 curve_id TEXT NOT NULL, residual_prime INTEGER NOT NULL, witness_prime_q INTEGER,
 trace_aq INTEGER, determinant_q INTEGER, charpoly_discriminant_mod_p INTEGER,
 legendre_symbol INTEGER, certificate_found INTEGER NOT NULL,
 expected_reducibility TEXT NOT NULL, check_pass INTEGER NOT NULL, notes TEXT,
 PRIMARY KEY(curve_id,residual_prime));

CREATE TABLE frobenius_witnesses (
  curve_id TEXT NOT NULL,
  prime_q INTEGER NOT NULL,
  point_count INTEGER NOT NULL,
  trace_aq INTEGER NOT NULL,
  determinant_q INTEGER NOT NULL,
  characteristic_polynomial TEXT NOT NULL,
  hasse_bound REAL NOT NULL,
  hasse_pass INTEGER NOT NULL,
  residual_prime INTEGER,
  trace_mod_residual INTEGER,
  determinant_mod_residual INTEGER,
  good_reduction INTEGER NOT NULL,
  PRIMARY KEY (curve_id, prime_q)
);

CREATE TABLE full_level_curve_geometry(
 level_p INTEGER PRIMARY KEY, psl2_index INTEGER NOT NULL, cusp_count INTEGER NOT NULL,
 genus INTEGER NOT NULL, calculation_pass INTEGER NOT NULL, notes TEXT);

CREATE TABLE g12_lift_generators_v20 (
  generator_id TEXT PRIMARY KEY,
  matrix_over_zsqrtminus2_json TEXT NOT NULL,
  determinant_json TEXT NOT NULL,
  square_identity INTEGER NOT NULL,
  reduction_mod3_json TEXT NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE g12_lift_group_certificates_v20 (
  certificate_id TEXT PRIMARY KEY,
  coefficient_ring TEXT NOT NULL,
  complex_embedding TEXT NOT NULL,
  generator_count INTEGER NOT NULL,
  group_order INTEGER NOT NULL,
  element_order_distribution_json TEXT NOT NULL,
  reflection_relation_failures INTEGER NOT NULL,
  presentation_relation_failures INTEGER NOT NULL,
  finite_image INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE g12_reduction_certificates_v20 (
  certificate_id TEXT PRIMARY KEY,
  prime_ideal TEXT NOT NULL,
  residue_field TEXT NOT NULL,
  reduced_group_order INTEGER NOT NULL,
  expected_gl2_order INTEGER NOT NULL,
  reduction_injective_on_group INTEGER NOT NULL,
  reduced_group_equals_gl2 INTEGER NOT NULL,
  stable_lattice_rank INTEGER NOT NULL,
  subgroup_restriction_rule INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE gl2f3_elements_v10 (
  element_id INTEGER PRIMARY KEY,
  matrix_json TEXT NOT NULL,
  determinant INTEGER NOT NULL,
  trace INTEGER NOT NULL,
  projective_class_id INTEGER NOT NULL,
  permutation_json TEXT NOT NULL,
  permutation_parity INTEGER NOT NULL
);

CREATE TABLE global_duality_compiler_cases_v21 (
  case_id TEXT PRIMARY KEY,
  residual_prime INTEGER NOT NULL,
  problem_id TEXT NOT NULL,
  finite_complex_count INTEGER NOT NULL,
  all_chain_conditions_pass INTEGER NOT NULL,
  local_conditions_typed INTEGER NOT NULL,
  orthogonal_conditions_typed INTEGER NOT NULL,
  finite_balance_controls_pass INTEGER NOT NULL,
  global_kernel_input INTEGER NOT NULL,
  representability_derived INTEGER NOT NULL,
  poitou_tate_derived INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE global_local_witnesses (
  model_id TEXT NOT NULL,
  prime_q INTEGER NOT NULL,
  component TEXT NOT NULL,
  vq_minimal_discriminant INTEGER NOT NULL,
  vq_minimal_c4 INTEGER NOT NULL,
  bad_reduction INTEGER NOT NULL,
  reduction_type TEXT NOT NULL,
  conductor_exponent INTEGER,
  minimality_pass INTEGER NOT NULL,
  conductor_radical_pass INTEGER NOT NULL,
  PRIMARY KEY (model_id, prime_q),
  FOREIGN KEY (model_id) REFERENCES normalized_frey_models(model_id)
);

CREATE TABLE good_prime_local_certificates_v14 (
 check_id TEXT PRIMARY KEY, calibration_id TEXT NOT NULL, residual_prime INTEGER NOT NULL,
 precision_n INTEGER NOT NULL, modulus INTEGER NOT NULL, frobenius_prime INTEGER NOT NULL,
 trace_value INTEGER NOT NULL, determinant_value INTEGER NOT NULL,
 characteristic_polynomial TEXT NOT NULL, hecke_relation_pass INTEGER NOT NULL,
 unramified_model_pass INTEGER NOT NULL, pass INTEGER NOT NULL);

CREATE TABLE good_reduction_multiplicity_certificates_v16 (
  certificate_id TEXT PRIMARY KEY,
  level_n INTEGER NOT NULL,
  residual_prime INTEGER NOT NULL,
  maximal_ideal_profile TEXT NOT NULL,
  residual_irreducible INTEGER NOT NULL,
  prime_not_dividing_level INTEGER NOT NULL,
  constituent_theorem_available INTEGER NOT NULL,
  oda_cotangent_comparison_available INTEGER NOT NULL,
  qexp_eigenline_dimension INTEGER NOT NULL,
  inferred_constituent_multiplicity INTEGER NOT NULL,
  inferred_torsion_dimension INTEGER NOT NULL,
  theorem_conclusion INTEGER NOT NULL,
  status TEXT NOT NULL,
  remaining_imports_json TEXT NOT NULL
);

CREATE TABLE graph_component_groups (
  graph_id TEXT PRIMARY KEY,
  smith_diagonal_json TEXT NOT NULL,
  component_group_order INTEGER NOT NULL,
  p_primary_invariant_factors_json TEXT NOT NULL,
  p_torsion_dimension INTEGER NOT NULL,
  monodromy_discriminant_order INTEGER NOT NULL,
  order_match_pass INTEGER NOT NULL,
  FOREIGN KEY (graph_id) REFERENCES reduction_graphs(graph_id)
);

CREATE TABLE group_ring_locality_certificates_v12 (
  certificate_id TEXT PRIMARY KEY,
  prime_p INTEGER NOT NULL,
  uniformizer_nilpotence INTEGER NOT NULL,
  group_exponents_json TEXT NOT NULL,
  basis_size INTEGER NOT NULL,
  element_count TEXT NOT NULL,
  tested_elements INTEGER NOT NULL,
  exhaustive INTEGER NOT NULL,
  unit_count INTEGER NOT NULL,
  nonunit_count INTEGER NOT NULL,
  expected_unit_count INTEGER,
  expected_nonunit_count INTEGER,
  nilpotence_bound INTEGER NOT NULL,
  inverse_failures INTEGER NOT NULL,
  nilpotence_failures INTEGER NOT NULL,
  local_ring_pass INTEGER NOT NULL
);

CREATE TABLE hecke_cohomology_module_contracts_v14 (
 contract_id TEXT PRIMARY KEY, coefficient_ring_contract TEXT NOT NULL,
 hecke_algebra_contract TEXT NOT NULL, module_contract TEXT NOT NULL,
 galois_action_contract TEXT NOT NULL, commuting_action_contract TEXT NOT NULL,
 good_prime_relation_contract TEXT NOT NULL, output_contract TEXT NOT NULL,
 status TEXT NOT NULL);

CREATE TABLE hecke_comparison_squares_v17 (
  check_id TEXT PRIMARY KEY,
  level_n INTEGER NOT NULL,
  residual_prime INTEGER NOT NULL,
  operator_label TEXT NOT NULL,
  integral_value INTEGER NOT NULL,
  finite_value INTEGER NOT NULL,
  commutes INTEGER NOT NULL,
  source_table TEXT NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE hecke_frobenius_pseudocharacter_stages_v13 (
  stage_id TEXT PRIMARY KEY,
  calibration_id TEXT NOT NULL,
  residual_prime INTEGER NOT NULL,
  precision_n INTEGER NOT NULL,
  modulus INTEGER NOT NULL,
  frobenius_primes_json TEXT NOT NULL,
  trace_values_json TEXT NOT NULL,
  determinant_values_json TEXT NOT NULL,
  hecke_trace_values_json TEXT NOT NULL,
  trace_match INTEGER NOT NULL,
  determinant_cyclotomic_match INTEGER NOT NULL,
  finite_stage_compatibility INTEGER NOT NULL,
  complete_group_pseudocharacter_supplied INTEGER NOT NULL,
  input_status TEXT NOT NULL
);

CREATE TABLE hecke_galois_assembly_v13 (
  assembly_id TEXT PRIMARY KEY,
  residual_prime INTEGER NOT NULL,
  pseudocharacter_stage_count INTEGER NOT NULL,
  pseudocharacter_input_present INTEGER NOT NULL,
  residual_absolute_irreducibility_present INTEGER NOT NULL,
  cayley_hamilton_compiler_available INTEGER NOT NULL,
  inverse_limit_compatibility_present INTEGER NOT NULL,
  local_model_count INTEGER NOT NULL,
  local_global_compatibility_present INTEGER NOT NULL,
  parent_representation_derived INTEGER NOT NULL,
  direct_parent_import_used INTEGER NOT NULL,
  status TEXT NOT NULL,
  remaining_imports_json TEXT NOT NULL
);

CREATE TABLE hecke_galois_obligations_v13 (
  obligation_id TEXT PRIMARY KEY,
  stage_order INTEGER NOT NULL,
  title TEXT NOT NULL,
  statement TEXT NOT NULL,
  status TEXT NOT NULL,
  witness_table TEXT,
  source_id TEXT,
  load_bearing INTEGER NOT NULL,
  exact_frontier TEXT NOT NULL
);

CREATE TABLE hecke_galois_parent_audit_v13 (
  edge_id TEXT PRIMARY KEY,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  pseudocharacter_compiler_internalized INTEGER NOT NULL,
  inverse_limit_compiler_internalized INTEGER NOT NULL,
  local_model_schema_internalized INTEGER NOT NULL,
  parent_removed INTEGER NOT NULL,
  child_import_count INTEGER NOT NULL,
  status TEXT NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE hecke_generator_coverage_v12 (
  certificate_id TEXT PRIMARY KEY,
  target_ring TEXT NOT NULL,
  generator_labels_json TEXT NOT NULL,
  generator_count INTEGER NOT NULL,
  covered_generator_count INTEGER NOT NULL,
  trace_generators_covered INTEGER NOT NULL,
  determinant_generators_covered INTEGER NOT NULL,
  local_u_generators_covered INTEGER NOT NULL,
  topological_generation_certified INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE hecke_level_conditions(witness_id TEXT PRIMARY KEY,form_id TEXT,residual_prime INTEGER,prime_q INTEGER,coefficient_aq INTEGER,sign INTEGER,target_value INTEGER,congruence_pass INTEGER,degeneracy_kernel_nonzero INTEGER,interpretation TEXT);

CREATE TABLE hecke_matrix_entries_v8 (
  operator_id TEXT NOT NULL,
  row_index INTEGER NOT NULL,
  column_index INTEGER NOT NULL,
  value INTEGER NOT NULL,
  PRIMARY KEY (operator_id,row_index,column_index),
  FOREIGN KEY (operator_id) REFERENCES hecke_operator_certificates_v8(operator_id)
);

CREATE TABLE hecke_operator_certificates_v8 (
  operator_id TEXT PRIMARY KEY,
  level_n INTEGER NOT NULL,
  residual_prime INTEGER NOT NULL,
  operator_kind TEXT NOT NULL,
  operator_index INTEGER NOT NULL,
  cuspidal_dimension INTEGER NOT NULL,
  relation_failure_count INTEGER NOT NULL,
  boundary_failure_count INTEGER NOT NULL,
  matrix_rank INTEGER NOT NULL,
  matrix_trace INTEGER NOT NULL,
  matrix_hash TEXT NOT NULL,
  commutes_with_packet_generators INTEGER NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE hecke_packet_certificates_v8 (
  packet_id TEXT PRIMARY KEY,
  level_n INTEGER NOT NULL,
  residual_prime INTEGER NOT NULL,
  generator_conditions_json TEXT NOT NULL,
  full_dimension INTEGER NOT NULL,
  plus_dimension INTEGER NOT NULL,
  minus_dimension INTEGER NOT NULL,
  expected_full_dimension INTEGER NOT NULL,
  expected_plus_dimension INTEGER NOT NULL,
  expected_minus_dimension INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  status TEXT NOT NULL,
  basis_hash TEXT NOT NULL
);

CREATE TABLE hecke_pseudocharacter_compatibility_v13 (
  check_id TEXT PRIMARY KEY,
  calibration_id TEXT NOT NULL,
  high_precision INTEGER NOT NULL,
  low_precision INTEGER NOT NULL,
  trace_reduction_pass INTEGER NOT NULL,
  determinant_reduction_pass INTEGER NOT NULL,
  hecke_reduction_pass INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE hecke_rank_transfer_certificates_v12 (
  certificate_id TEXT PRIMARY KEY,
  coefficient_ring TEXT NOT NULL,
  delta_group TEXT NOT NULL,
  cohomology_free_rank_over_group_ring INTEGER NOT NULL,
  cohomology_free_rank_over_hecke INTEGER NOT NULL,
  hecke_free_rank_over_group_ring INTEGER NOT NULL,
  base_hecke_rank INTEGER NOT NULL,
  ranks_match INTEGER NOT NULL,
  proof_rule TEXT NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE hecke_relation_checks (
  check_id TEXT PRIMARY KEY,
  form_id TEXT NOT NULL,
  relation_type TEXT NOT NULL,
  lhs_index INTEGER NOT NULL,
  rhs_indices_json TEXT NOT NULL,
  lhs_value INTEGER NOT NULL,
  rhs_value INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  FOREIGN KEY (form_id) REFERENCES eta_quotient_witnesses(form_id)
);

CREATE TABLE hecke_validation_checks_v8 (
  check_id TEXT PRIMARY KEY,
  level_n INTEGER NOT NULL,
  residual_prime INTEGER NOT NULL,
  operator_id TEXT NOT NULL,
  expected_scalar INTEGER NOT NULL,
  scalar_matrix INTEGER NOT NULL,
  observed_characteristic_polynomial TEXT NOT NULL,
  pass INTEGER NOT NULL,
  FOREIGN KEY (operator_id) REFERENCES hecke_operator_certificates_v8(operator_id)
);

CREATE TABLE hilbert_parent_audit_v19 (
  edge_id TEXT PRIMARY KEY,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  finite_local_open_compiler_internalized INTEGER NOT NULL,
  thin_set_compiler_internalized INTEGER NOT NULL,
  parent_removed INTEGER NOT NULL,
  child_import_count INTEGER NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE hilbert_selection_obligations_v19 (
  obligation_id TEXT PRIMARY KEY,
  stage_order INTEGER NOT NULL,
  title TEXT NOT NULL,
  statement TEXT NOT NULL,
  status TEXT NOT NULL,
  witness_table TEXT,
  source_id TEXT,
  exact_frontier TEXT NOT NULL
);

CREATE TABLE hilbert_selection_witnesses(
 witness_id TEXT PRIMARY KEY, polynomial_family TEXT NOT NULL, specialization_t1 INTEGER NOT NULL,
 irreducible_over_q INTEGER NOT NULL, auxiliary_prime INTEGER NOT NULL,
 no_root_mod_auxiliary INTEGER NOT NULL, local_modulus INTEGER NOT NULL,
 local_target INTEGER NOT NULL, selected_t0 INTEGER NOT NULL,
 crt_pass INTEGER NOT NULL, selected_no_root_mod_auxiliary INTEGER NOT NULL,
 theorem_status TEXT NOT NULL, notes TEXT);

CREATE TABLE homological_multiplicity_certificates_v8 (
  certificate_id TEXT PRIMARY KEY,
  level_n INTEGER NOT NULL,
  residual_prime INTEGER NOT NULL,
  maximal_ideal_generators_json TEXT NOT NULL,
  full_homology_m_torsion_dimension INTEGER NOT NULL,
  plus_packet_dimension INTEGER NOT NULL,
  minus_packet_dimension INTEGER NOT NULL,
  expected_full_dimension INTEGER NOT NULL,
  expected_sign_dimension INTEGER NOT NULL,
  homological_multiplicity_one INTEGER NOT NULL,
  modular_form_packet_unique INTEGER NOT NULL,
  theorem_scope TEXT NOT NULL,
  status TEXT NOT NULL,
  remaining_imports_json TEXT NOT NULL
);

CREATE TABLE hopf_group_schemes(scheme_id TEXT PRIMARY KEY,prime_p INTEGER,name TEXT,coordinate_algebra TEXT,algebra_dimension INTEGER,connected INTEGER,etale INTEGER,generic_fiber_order INTEGER,comultiplication_rule TEXT,counit_rule TEXT,antipode_rule TEXT,epistemic_tier TEXT);

CREATE TABLE hopf_structure_checks(check_id TEXT PRIMARY KEY,scheme_id TEXT,prime_p INTEGER,check_kind TEXT,tested_tuple_json TEXT,lhs_json TEXT,rhs_json TEXT,pass INTEGER);

CREATE TABLE ihara_calibration_certificates_v7 (
  certificate_id TEXT PRIMARY KEY,
  profile_id TEXT,
  base_level_n INTEGER NOT NULL,
  raised_level_nq INTEGER NOT NULL,
  removed_prime_q INTEGER NOT NULL,
  residual_prime INTEGER NOT NULL,
  map_id TEXT NOT NULL,
  non_eisenstein_hypothesis INTEGER NOT NULL,
  direct_homology_surjectivity INTEGER NOT NULL,
  dual_cohomology_injectivity INTEGER NOT NULL,
  localized_kernel_dimension INTEGER NOT NULL,
  edge_closed INTEGER NOT NULL,
  status TEXT NOT NULL,
  remaining_imports_json TEXT NOT NULL,
  FOREIGN KEY (map_id) REFERENCES degeneracy_map_certificates_v7(map_id)
);

CREATE TABLE ihara_localization_witnesses (
  witness_id TEXT PRIMARY KEY,
  profile_id TEXT NOT NULL,
  source_level INTEGER NOT NULL,
  raised_level INTEGER NOT NULL,
  auxiliary_prime_q INTEGER NOT NULL,
  raw_composition_kernel_dimension INTEGER NOT NULL,
  non_eisenstein_hypothesis INTEGER NOT NULL,
  ihara_applicable INTEGER NOT NULL,
  localized_degeneracy_kernel_dimension INTEGER,
  conclusion_status TEXT NOT NULL,
  source_id TEXT,
  FOREIGN KEY (profile_id) REFERENCES maximal_ideal_profiles(profile_id)
);

CREATE TABLE ihara_proof_obligations_v7 (
  obligation_id TEXT PRIMARY KEY,
  stage_order INTEGER NOT NULL,
  title TEXT NOT NULL,
  statement TEXT NOT NULL,
  status TEXT NOT NULL,
  witness_table TEXT,
  source_id TEXT,
  load_bearing INTEGER NOT NULL,
  exact_remaining_frontier TEXT NOT NULL
);

CREATE TABLE implication_rules (
  rule_id TEXT PRIMARY KEY,
  antecedents_json TEXT NOT NULL,
  consequent TEXT NOT NULL,
  rule_kind TEXT NOT NULL,
  status TEXT NOT NULL,
  source_id TEXT,
  notes TEXT,
  FOREIGN KEY (source_id) REFERENCES sources(source_id)
);

CREATE TABLE import_surface (
  edge_id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  source_id TEXT NOT NULL,
  antecedent_geometry_witnessed INTEGER NOT NULL,
  consequent_used_in_main_trace INTEGER NOT NULL,
  proof_internalized INTEGER NOT NULL,
  load_bearing INTEGER NOT NULL,
  next_decomposition_target TEXT NOT NULL,
  FOREIGN KEY (source_id) REFERENCES sources(source_id)
);

CREATE TABLE inertia_cocycle_witnesses(witness_id TEXT PRIMARY KEY,prime_p INTEGER,valuation_v INTEGER,cocycle_class INTEGER,generator_matrix_json TEXT,matrix_order INTEGER,fixed_space_dimension INTEGER,unramified INTEGER,finite_flat_candidate INTEGER,criterion_source TEXT);

CREATE TABLE inference_coverage(singleton INTEGER PRIMARY KEY,total_loops INTEGER,algebraic_or_finite_loops INTEGER,conditional_loops INTEGER,imported_edge_count INTEGER,imported_edge_antecedents_witnessed INTEGER,main_trace_steps INTEGER,internally_derived_trace_steps INTEGER,imported_trace_steps INTEGER,contradiction_derived INTEGER,coverage_note TEXT);

CREATE TABLE integral_form_lattices_v9 (
  lattice_id TEXT PRIMARY KEY,
  form_id TEXT NOT NULL,
  level_n INTEGER NOT NULL,
  weight_k INTEGER NOT NULL,
  coefficient_ring TEXT NOT NULL,
  fraction_field TEXT NOT NULL,
  module_rank INTEGER NOT NULL,
  torsion_free INTEGER NOT NULL,
  normalized INTEGER NOT NULL,
  first_coefficient INTEGER NOT NULL,
  coefficient_count INTEGER NOT NULL,
  coefficient_hash TEXT NOT NULL,
  target_space_dimension INTEGER NOT NULL,
  rank_dimension_match INTEGER NOT NULL,
  modularity_status TEXT NOT NULL,
  source_id TEXT
);

CREATE TABLE integral_hecke_actions_v9 (
  action_id TEXT PRIMARY KEY,
  lattice_id TEXT NOT NULL,
  operator_label TEXT NOT NULL,
  operator_index INTEGER NOT NULL,
  eigenvalue_integer INTEGER NOT NULL,
  scalar_matrix_json TEXT NOT NULL,
  reduction_mod_7 INTEGER NOT NULL,
  recurrence_or_source_check INTEGER NOT NULL,
  action_pass INTEGER NOT NULL,
  FOREIGN KEY (lattice_id) REFERENCES integral_form_lattices_v9(lattice_id)
);

CREATE TABLE invariant_checks (
  check_id TEXT PRIMARY KEY,
  description TEXT NOT NULL,
  tier TEXT NOT NULL,
  pass_count INTEGER NOT NULL,
  fail_count INTEGER NOT NULL,
  universe_count INTEGER NOT NULL,
  status TEXT NOT NULL,
  evidence TEXT NOT NULL,
  protects_loop TEXT,
  FOREIGN KEY (protects_loop) REFERENCES loops(loop_id)
);

CREATE TABLE involution_split_certificates_v12 (
  certificate_id TEXT PRIMARY KEY,
  prime_p INTEGER NOT NULL,
  module_rank INTEGER NOT NULL,
  involution_matrix_json TEXT NOT NULL,
  square_identity INTEGER NOT NULL,
  two_invertible INTEGER NOT NULL,
  plus_projector_rank INTEGER NOT NULL,
  minus_projector_rank INTEGER NOT NULL,
  direct_sum_rank INTEGER NOT NULL,
  local_ring_projective_free INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE irreducibility_parent_audit_v18 (
  edge_id TEXT PRIMARY KEY,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  shared_isogeny_child_count INTEGER NOT NULL,
  internal_group_children INTEGER NOT NULL,
  parent_removed INTEGER NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE isogeny_correspondences(
 edge_order INTEGER PRIMARY KEY, antecedent TEXT NOT NULL, consequent TEXT NOT NULL,
 edge_kind TEXT NOT NULL, witness_status TEXT NOT NULL, notes TEXT);

CREATE TABLE isogeny_degree_certificates_v18 (
  certificate_id TEXT PRIMARY KEY,
  residual_prime INTEGER NOT NULL,
  induced_cyclic_degree INTEGER NOT NULL,
  degree_allowed_by_classification INTEGER NOT NULL,
  frey_local_obstruction_required INTEGER NOT NULL,
  rational_isogeny_excluded INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE isogeny_formal_immersion_obligations_v19 (
  obligation_id TEXT PRIMARY KEY,
  stage_order INTEGER NOT NULL,
  title TEXT NOT NULL,
  statement TEXT NOT NULL,
  status TEXT NOT NULL,
  witness_table TEXT,
  source_id TEXT,
  exact_frontier TEXT NOT NULL
);

CREATE TABLE isogeny_parent_audit_v19 (
  edge_id TEXT PRIMARY KEY,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  degree_ledger_internalized INTEGER NOT NULL,
  cusp_specialization_internalized INTEGER NOT NULL,
  formal_immersion_internalized INTEGER NOT NULL,
  parent_removed INTEGER NOT NULL,
  child_import_count INTEGER NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE kummer_component_law_checks_v20 (
  check_id TEXT PRIMARY KEY,
  residual_prime INTEGER NOT NULL,
  triple_count INTEGER NOT NULL,
  associativity_failures INTEGER NOT NULL,
  carry_failures INTEGER NOT NULL,
  inverse_failures INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE kummer_group_scheme_certificates_v20 (
  certificate_id TEXT PRIMARY KEY,
  residual_prime INTEGER NOT NULL,
  base_ring_contract TEXT NOT NULL,
  unit_parameter TEXT NOT NULL,
  component_count INTEGER NOT NULL,
  rank_per_component INTEGER NOT NULL,
  total_rank INTEGER NOT NULL,
  component_equations_json TEXT NOT NULL,
  kernel_scheme TEXT NOT NULL,
  quotient_scheme TEXT NOT NULL,
  finite INTEGER NOT NULL,
  flat INTEGER NOT NULL,
  exact_sequence INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE kummer_local_profiles(
 profile_id TEXT PRIMARY KEY, residual_prime INTEGER NOT NULL, local_prime INTEGER NOT NULL,
 tate_valuation INTEGER NOT NULL, local_case TEXT NOT NULL, valuation_mod_p INTEGER NOT NULL,
 predicted_ramification_index INTEGER, unramified_or_finite INTEGER,
 theorem_status TEXT NOT NULL, notes TEXT);

CREATE TABLE langlands_tunnell_obligations_v19 (
  obligation_id TEXT PRIMARY KEY,
  stage_order INTEGER NOT NULL,
  title TEXT NOT NULL,
  statement TEXT NOT NULL,
  status TEXT NOT NULL,
  witness_table TEXT,
  source_id TEXT,
  exact_frontier TEXT NOT NULL
);

CREATE TABLE langlands_tunnell_parent_audit_v19 (
  edge_id TEXT PRIMARY KEY,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  finite_type_router_internalized INTEGER NOT NULL,
  local_factor_compiler_internalized INTEGER NOT NULL,
  parent_removed INTEGER NOT NULL,
  child_import_count INTEGER NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE large_image_certificates_v18 (
  certificate_id TEXT PRIMARY KEY,
  residual_prime INTEGER NOT NULL,
  irreducibility_input INTEGER NOT NULL,
  semistable_inertia_profile INTEGER NOT NULL,
  transvection_generation_pass INTEGER NOT NULL,
  determinant_surjective INTEGER NOT NULL,
  gl2_image_derived INTEGER NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE level_lowering_contracts_v21 (
  certificate_id TEXT PRIMARY KEY,
  concrete_closed_branches INTEGER NOT NULL,
  modular_symbol_generator_available INTEGER NOT NULL,
  component_group_generator_available INTEGER NOT NULL,
  multiplicity_generator_available INTEGER NOT NULL,
  lifting_generator_available INTEGER NOT NULL,
  local_profile_complete INTEGER NOT NULL,
  universal_kernel_input INTEGER NOT NULL,
  level_two_form_derived INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  remaining_scope TEXT NOT NULL
);

CREATE TABLE level_lowering_obligations(obligation_id TEXT PRIMARY KEY,stage_order INTEGER,title TEXT,antecedents_json TEXT,consequent TEXT,witness_table TEXT,status TEXT,source_id TEXT,load_bearing INTEGER,notes TEXT);

CREATE TABLE level_lowering_steps (
  profile_id TEXT NOT NULL,
  step_no INTEGER NOT NULL,
  level_before TEXT NOT NULL,
  removed_prime INTEGER,
  removal_reason TEXT NOT NULL,
  level_after TEXT NOT NULL,
  anchor_prime_2_present INTEGER NOT NULL,
  imported_rule_used TEXT,
  terminal_level_2 INTEGER NOT NULL,
  PRIMARY KEY (profile_id, step_no),
  FOREIGN KEY (profile_id) REFERENCES formal_flt_profiles(profile_id)
);

CREATE TABLE lifting_counterfactuals_v9 (
  test_id TEXT PRIMARY KEY,
  model_description TEXT NOT NULL,
  module_rank INTEGER NOT NULL,
  torsion_free INTEGER NOT NULL,
  commuting INTEGER NOT NULL,
  residual_eigenspace_dimension INTEGER NOT NULL,
  lift_over_base_fraction_field INTEGER NOT NULL,
  lift_after_finite_extension INTEGER NOT NULL,
  unique_lift INTEGER NOT NULL,
  expected_classification TEXT NOT NULL,
  pass INTEGER NOT NULL,
  interpretation TEXT NOT NULL
);

CREATE TABLE lifting_obligations_v9 (
  obligation_id TEXT PRIMARY KEY,
  stage_order INTEGER NOT NULL,
  title TEXT NOT NULL,
  statement TEXT NOT NULL,
  status TEXT NOT NULL,
  witness_table TEXT,
  source_id TEXT,
  load_bearing INTEGER NOT NULL,
  exact_remaining_frontier TEXT NOT NULL
);

CREATE TABLE local_deformation_conditions_v10 (
  problem_id TEXT NOT NULL,
  place TEXT NOT NULL,
  condition_kind TEXT NOT NULL,
  tangent_coordinate_contract TEXT NOT NULL,
  obstruction_coordinate_contract TEXT NOT NULL,
  finite_adapter_status TEXT NOT NULL,
  theorem_status TEXT NOT NULL,
  PRIMARY KEY (problem_id,place)
);

CREATE TABLE local_global_compatibility_frontier_v13 (
  frontier_id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  statement TEXT NOT NULL,
  status TEXT NOT NULL,
  source_id TEXT NOT NULL,
  exact_missing_adapter TEXT NOT NULL,
  load_bearing INTEGER NOT NULL
);

CREATE TABLE local_global_counterfactuals_v14 (
 test_id TEXT PRIMARY KEY, malformed_input TEXT NOT NULL, good_model_pass INTEGER NOT NULL,
 ordinary_model_pass INTEGER NOT NULL, steinberg_model_pass INTEGER NOT NULL,
 comparison_input_present INTEGER NOT NULL, parent_derived INTEGER NOT NULL,
 expected_parent_derived INTEGER NOT NULL, pass INTEGER NOT NULL, interpretation TEXT NOT NULL);

CREATE TABLE local_global_obligations_v14 (
 obligation_id TEXT PRIMARY KEY, stage_order INTEGER NOT NULL, title TEXT NOT NULL,
 statement TEXT NOT NULL, status TEXT NOT NULL, witness_table TEXT, source_id TEXT,
 load_bearing INTEGER NOT NULL, exact_frontier TEXT NOT NULL);

CREATE TABLE local_global_parent_audit_v14 (
 edge_id TEXT PRIMARY KEY, previous_status TEXT NOT NULL, current_status TEXT NOT NULL,
 good_prime_internalized INTEGER NOT NULL, ordinary_model_internalized INTEGER NOT NULL,
 steinberg_model_internalized INTEGER NOT NULL, parent_removed INTEGER NOT NULL,
 child_import_count INTEGER NOT NULL, status TEXT NOT NULL, next_target TEXT NOT NULL);

CREATE TABLE local_model_gluing_certificates_v14 (
 certificate_id TEXT PRIMARY KEY, residual_prime INTEGER NOT NULL,
 good_prime_rows INTEGER NOT NULL, ordinary_stage_rows INTEGER NOT NULL,
 steinberg_stage_rows INTEGER NOT NULL, finite_flat_contract_present INTEGER NOT NULL,
 internal_local_models_pass INTEGER NOT NULL, comparison_input_present INTEGER NOT NULL,
 parent_compatibility_derived INTEGER NOT NULL, direct_parent_import_used INTEGER NOT NULL,
 status TEXT NOT NULL, remaining_imports_json TEXT NOT NULL);

CREATE TABLE local_open_constraints_v19 (
  constraint_id TEXT PRIMARY KEY,
  profile_id TEXT NOT NULL,
  prime_p INTEGER NOT NULL,
  allowed_residues_json TEXT NOT NULL,
  selected_residue INTEGER NOT NULL,
  local_condition TEXT NOT NULL,
  pass INTEGER NOT NULL,
  FOREIGN KEY (profile_id) REFERENCES thin_set_profiles_v19(profile_id)
);

CREATE TABLE local_prime_witnesses (
  sample_id TEXT NOT NULL,
  prime_q INTEGER NOT NULL,
  divides_a INTEGER NOT NULL,
  divides_b INTEGER NOT NULL,
  divides_c_power_sum INTEGER NOT NULL,
  v_discriminant INTEGER NOT NULL,
  v_c4 INTEGER NOT NULL,
  odd_bad_prime INTEGER NOT NULL,
  reduction_type_away_from_2 TEXT NOT NULL,
  conductor_exponent_away_from_2 INTEGER,
  valuation_divisible_by_p_observed INTEGER NOT NULL,
  valuation_divisible_by_p_under_flt_condition INTEGER NOT NULL,
  check_pass INTEGER NOT NULL,
  notes TEXT,
  PRIMARY KEY (sample_id, prime_q),
  FOREIGN KEY (sample_id) REFERENCES frey_samples(sample_id)
);

CREATE TABLE local_representation_models_v13 (
  model_id TEXT PRIMARY KEY,
  level_n INTEGER NOT NULL,
  residual_prime INTEGER NOT NULL,
  local_prime_q INTEGER NOT NULL,
  local_type TEXT NOT NULL,
  hecke_operator_label TEXT NOT NULL,
  hecke_operator_value INTEGER NOT NULL,
  determinant_character TEXT NOT NULL,
  model_shape TEXT NOT NULL,
  finite_parameter_check INTEGER NOT NULL,
  global_identification_status TEXT NOT NULL,
  source_id TEXT
);

CREATE TABLE localized_hecke_algebras_v9 (
  algebra_id TEXT PRIMARY KEY,
  lattice_id TEXT NOT NULL,
  image_ring TEXT NOT NULL,
  localization TEXT NOT NULL,
  completion TEXT NOT NULL,
  residue_field TEXT NOT NULL,
  algebra_rank INTEGER NOT NULL,
  module_rank INTEGER NOT NULL,
  maximal_ideal_generators_json TEXT NOT NULL,
  scalar_action INTEGER NOT NULL,
  finite_free INTEGER NOT NULL,
  residue_character_json TEXT NOT NULL,
  algebra_pass INTEGER NOT NULL,
  FOREIGN KEY (lattice_id) REFERENCES integral_form_lattices_v9(lattice_id)
);

CREATE TABLE loops (
  loop_id TEXT PRIMARY KEY,
  loop_order INTEGER NOT NULL,
  title TEXT NOT NULL,
  status TEXT NOT NULL,
  new_concept TEXT NOT NULL,
  domain_question TEXT NOT NULL,
  witness_summary TEXT,
  next_frontier TEXT,
  epistemic_tier TEXT NOT NULL
);

CREATE TABLE lower_level_eigenform_certificates (
  certificate_id TEXT PRIMARY KEY,
  residual_prime INTEGER NOT NULL,
  source_level INTEGER NOT NULL,
  removed_prime_q INTEGER NOT NULL,
  target_level INTEGER NOT NULL,
  maximal_ideal_profile TEXT NOT NULL,
  hecke_congruence_witness INTEGER NOT NULL,
  ihara_gate_pass INTEGER NOT NULL,
  component_bridge_pass INTEGER NOT NULL,
  multiplicity_one_pass INTEGER NOT NULL,
  eigenpacket_lift_pass INTEGER NOT NULL,
  target_space_dimension INTEGER NOT NULL,
  target_form_id TEXT,
  lower_level_form_derived INTEGER NOT NULL,
  status TEXT NOT NULL,
  imported_edges_json TEXT NOT NULL,
  rejection_reason TEXT,
  FOREIGN KEY (maximal_ideal_profile) REFERENCES maximal_ideal_profiles(profile_id)
);

CREATE TABLE lowering_certificate_revisions_v6 (
  certificate_id TEXT PRIMARY KEY,
  previous_status TEXT NOT NULL,
  revised_status TEXT NOT NULL,
  previous_imports_json TEXT NOT NULL,
  revised_imports_json TEXT NOT NULL,
  component_edge_removed INTEGER NOT NULL,
  invalidated_prior_model_reference TEXT,
  corrected_model_reference TEXT,
  valid_from_loop INTEGER NOT NULL,
  recorded_at TEXT NOT NULL
);

CREATE TABLE lowering_certificate_revisions_v7 (
  revision_id TEXT PRIMARY KEY,
  certificate_id TEXT NOT NULL,
  previous_status TEXT NOT NULL,
  revised_status TEXT NOT NULL,
  previous_imports_json TEXT NOT NULL,
  revised_imports_json TEXT NOT NULL,
  ihara_edge_removed INTEGER NOT NULL,
  modular_symbol_certificate_id TEXT NOT NULL,
  valid_from_loop INTEGER NOT NULL,
  recorded_at TEXT NOT NULL
);

CREATE TABLE lowering_certificate_revisions_v8 (
  revision_id TEXT PRIMARY KEY,
  certificate_id TEXT NOT NULL,
  previous_status TEXT NOT NULL,
  revised_status TEXT NOT NULL,
  previous_imports_json TEXT NOT NULL,
  revised_imports_json TEXT NOT NULL,
  multiplicity_edge_removed INTEGER NOT NULL,
  multiplicity_certificate_id TEXT NOT NULL,
  valid_from_loop INTEGER NOT NULL,
  recorded_at TEXT NOT NULL
);

CREATE TABLE lowering_certificate_revisions_v9 (
  revision_id TEXT PRIMARY KEY,
  certificate_id TEXT NOT NULL,
  previous_status TEXT NOT NULL,
  revised_status TEXT NOT NULL,
  previous_imports_json TEXT NOT NULL,
  revised_imports_json TEXT NOT NULL,
  lifting_edge_removed INTEGER NOT NULL,
  lift_certificate_id TEXT NOT NULL,
  valid_from_loop INTEGER NOT NULL,
  recorded_at TEXT NOT NULL
);

CREATE TABLE manin_generators_v7 (
  module_id TEXT NOT NULL,
  generator_index INTEGER NOT NULL,
  c_mod_n INTEGER NOT NULL,
  d_mod_n INTEGER NOT NULL,
  pivot_generator INTEGER NOT NULL,
  free_generator INTEGER NOT NULL,
  boundary_vector_json TEXT NOT NULL,
  PRIMARY KEY (module_id,generator_index),
  FOREIGN KEY (module_id) REFERENCES manin_module_certificates_v7(module_id)
);

CREATE TABLE manin_module_certificates_v7 (
  module_id TEXT PRIMARY KEY,
  level_n INTEGER NOT NULL,
  residual_prime INTEGER NOT NULL,
  squarefree INTEGER NOT NULL,
  p1_count INTEGER NOT NULL,
  relation_count INTEGER NOT NULL,
  relation_rank INTEGER NOT NULL,
  relative_dimension INTEGER NOT NULL,
  cusp_count INTEGER NOT NULL,
  boundary_rank INTEGER NOT NULL,
  cuspidal_dimension INTEGER NOT NULL,
  expected_cuspidal_dimension INTEGER NOT NULL,
  dimension_pass INTEGER NOT NULL,
  relations_hash TEXT NOT NULL,
  boundary_hash TEXT NOT NULL
);

CREATE TABLE manin_relation_certificates_v7 (
  module_id TEXT PRIMARY KEY,
  s_relation_count INTEGER NOT NULL,
  r_relation_count INTEGER NOT NULL,
  total_relation_count INTEGER NOT NULL,
  relation_rank INTEGER NOT NULL,
  quotient_dimension INTEGER NOT NULL,
  all_rref_pivots_unique INTEGER NOT NULL,
  relation_matrix_hash TEXT NOT NULL,
  pass INTEGER NOT NULL,
  FOREIGN KEY (module_id) REFERENCES manin_module_certificates_v7(module_id)
);

CREATE TABLE matrix_unit_certificates_v13 (
  stage_id TEXT PRIMARY KEY,
  matrix_unit_coefficients_json TEXT NOT NULL,
  relation_count INTEGER NOT NULL,
  relation_failure_count INTEGER NOT NULL,
  split_matrix_algebra INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  FOREIGN KEY (stage_id) REFERENCES pseudocharacter_stages_v13(stage_id)
);

CREATE TABLE maximal_ideal_profiles (
  profile_id TEXT PRIMARY KEY,
  form_id TEXT NOT NULL,
  residual_prime INTEGER NOT NULL,
  tested_prime_count INTEGER NOT NULL,
  eisenstein_congruence_count INTEGER NOT NULL,
  eisenstein INTEGER NOT NULL,
  rational_torsion_witness INTEGER NOT NULL,
  irreducibility_certificate INTEGER NOT NULL,
  non_eisenstein_gate INTEGER NOT NULL,
  notes TEXT
);

CREATE TABLE mazur_prime_isogeny_geometry(
 prime_p INTEGER PRIMARY KEY, rational_prime_isogeny_possible INTEGER NOT NULL,
 semistable_surjectivity_rule_applies INTEGER NOT NULL,
 frey_small_prime_rule_applies INTEGER NOT NULL, flt_route TEXT NOT NULL,
 theorem_status TEXT NOT NULL, source_id TEXT, notes TEXT);

CREATE TABLE minimal_level_runs(run_id TEXT PRIMARY KEY,starting_level INTEGER,residual_prime INTEGER,removable_primes_json TEXT,retained_primes_json TEXT,levels_json TEXT,terminal_level INTEGER,contradiction_target TEXT,imported_obligation_count INTEGER,pass INTEGER);

CREATE TABLE mod3_brauer_lift_obligations_v18 (
  obligation_id TEXT PRIMARY KEY,
  stage_order INTEGER NOT NULL,
  title TEXT NOT NULL,
  statement TEXT NOT NULL,
  status TEXT NOT NULL,
  witness_table TEXT,
  source_id TEXT,
  exact_frontier TEXT NOT NULL
);

CREATE TABLE mod3_image_brauer_profiles_v18 (
  profile_id TEXT PRIMARY KEY,
  image_group TEXT NOT NULL,
  group_order INTEGER NOT NULL,
  solvable INTEGER NOT NULL,
  residual_dimension INTEGER NOT NULL,
  residual_irreducible INTEGER NOT NULL,
  p_regular_class_count INTEGER NOT NULL,
  brauer_character_contract TEXT NOT NULL,
  determinant_character TEXT NOT NULL,
  oddness_compatible INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE mod3_image_profiles_v10 (
  profile_id TEXT PRIMARY KEY,
  profile_kind TEXT NOT NULL,
  residual_prime INTEGER NOT NULL,
  irreducible INTEGER NOT NULL,
  odd INTEGER NOT NULL,
  projective_image_contained_s4 INTEGER NOT NULL,
  every_possible_projective_image_solvable INTEGER NOT NULL,
  complex_lift_status TEXT NOT NULL,
  modularity_status TEXT NOT NULL,
  remaining_imports_json TEXT NOT NULL
);

CREATE TABLE modular_curve_cusp_profiles_v19 (
  level_n INTEGER PRIMARY KEY,
  genus INTEGER NOT NULL,
  cusp_count INTEGER NOT NULL,
  relevant_prime INTEGER NOT NULL,
  special_fiber_cusp_label TEXT NOT NULL,
  rank_zero_quotient_contract TEXT NOT NULL,
  local_specialization_contract TEXT NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE modular_curve_witnesses (
  level_n INTEGER PRIMARY KEY,
  index_mu INTEGER NOT NULL,
  cusp_count INTEGER NOT NULL,
  elliptic_points_order_2 INTEGER NOT NULL,
  elliptic_points_order_3 INTEGER NOT NULL,
  genus INTEGER NOT NULL,
  dim_s2 INTEGER NOT NULL,
  check_pass INTEGER NOT NULL,
  notes TEXT
);

CREATE TABLE modular_dimension_phase (
  level_n INTEGER PRIMARY KEY,
  gamma0_index INTEGER NOT NULL,
  cusp_count INTEGER NOT NULL,
  elliptic_points_order_2 INTEGER NOT NULL,
  elliptic_points_order_3 INTEGER NOT NULL,
  genus_x0 INTEGER NOT NULL,
  dim_s2 INTEGER NOT NULL,
  sturm_bound_weight_2 INTEGER NOT NULL,
  zero_space INTEGER NOT NULL,
  first_positive_dimension INTEGER NOT NULL
);

CREATE TABLE modular_integral_models (
  model_id TEXT PRIMARY KEY,
  generic_curve TEXT NOT NULL,
  base_ring TEXT NOT NULL,
  level_n INTEGER,
  bad_prime_q INTEGER,
  component_count INTEGER,
  component_normalization TEXT,
  intersection_adapter_status TEXT NOT NULL,
  geometry_status TEXT NOT NULL,
  source_id TEXT,
  notes TEXT
);

CREATE TABLE modular_pseudocharacter_obligations_v14 (
 obligation_id TEXT PRIMARY KEY, stage_order INTEGER NOT NULL, title TEXT NOT NULL,
 statement TEXT NOT NULL, status TEXT NOT NULL, witness_table TEXT, source_id TEXT,
 load_bearing INTEGER NOT NULL, exact_frontier TEXT NOT NULL);

CREATE TABLE modular_pseudocharacter_parent_audit_v14 (
 edge_id TEXT PRIMARY KEY, previous_status TEXT NOT NULL, current_status TEXT NOT NULL,
 module_to_pseudocharacter_internalized INTEGER NOT NULL,
 basis_independence_internalized INTEGER NOT NULL,
 inverse_limit_internalized INTEGER NOT NULL, parent_removed INTEGER NOT NULL,
 child_import_count INTEGER NOT NULL, status TEXT NOT NULL, next_target TEXT NOT NULL);

CREATE TABLE modularity_lifting_architecture(
 node_order INTEGER PRIMARY KEY, node_id TEXT UNIQUE NOT NULL, title TEXT NOT NULL,
 inputs_json TEXT NOT NULL, output_fact TEXT NOT NULL, node_kind TEXT NOT NULL,
 source_id TEXT, witnessed INTEGER NOT NULL, imported INTEGER NOT NULL, notes TEXT);

CREATE TABLE module_pseudocharacter_certificates_v14 (
 certificate_id TEXT PRIMARY KEY, stage_id TEXT NOT NULL, module_rank INTEGER NOT NULL,
 trace_values_json TEXT NOT NULL, determinant_values_json TEXT NOT NULL,
 pseudocharacter_identity_pass INTEGER NOT NULL, basis_independent INTEGER NOT NULL,
 characteristic_polynomials_json TEXT NOT NULL, pass INTEGER NOT NULL);

CREATE TABLE module_pseudocharacter_counterfactuals_v14 (
 test_id TEXT PRIMARY KEY, violated_condition TEXT NOT NULL, module_free_rank_two INTEGER NOT NULL,
 commuting_actions INTEGER NOT NULL, group_action INTEGER NOT NULL,
 compiler_accept INTEGER NOT NULL, expected_accept INTEGER NOT NULL, pass INTEGER NOT NULL,
 interpretation TEXT NOT NULL);

CREATE TABLE module_stage_compatibility_v14 (
 check_id TEXT PRIMARY KEY, prime_p INTEGER NOT NULL, high_precision INTEGER NOT NULL,
 low_precision INTEGER NOT NULL, action_reduction_pass INTEGER NOT NULL,
 trace_reduction_pass INTEGER NOT NULL, determinant_reduction_pass INTEGER NOT NULL,
 pass INTEGER NOT NULL);

CREATE TABLE monodromy_comparison_certificates_v17 (
  certificate_id TEXT PRIMARY KEY,
  model_id TEXT NOT NULL,
  residual_prime INTEGER NOT NULL,
  local_prime INTEGER NOT NULL,
  lattice_rank INTEGER NOT NULL,
  monodromy_matrix_json TEXT NOT NULL,
  monodromy_rank INTEGER NOT NULL,
  monodromy_square_zero INTEGER NOT NULL,
  kernel_dimension INTEGER NOT NULL,
  image_dimension INTEGER NOT NULL,
  u_operator_label TEXT NOT NULL,
  u_operator_value INTEGER NOT NULL,
  nearby_cycles_input INTEGER NOT NULL,
  comparison_derived INTEGER NOT NULL,
  direct_parent_import_used INTEGER NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE monodromy_pairing_toys(toy_id TEXT PRIMARY KEY,lattice_rank INTEGER,pairing_matrix_json TEXT,determinant INTEGER,discriminant_group_order INTEGER,residual_prime INTEGER,nonsingular_mod_p INTEGER,pass INTEGER);

CREATE TABLE monodromy_pairing_witnesses_v5 (
  model_id TEXT PRIMARY KEY,
  weight_diagonal_json TEXT NOT NULL,
  basis_matrix_json TEXT NOT NULL,
  pairing_matrix_json TEXT NOT NULL,
  determinant INTEGER NOT NULL,
  positive_definite INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  source_id TEXT,
  FOREIGN KEY (model_id) REFERENCES modular_integral_models(model_id)
);

CREATE TABLE multiplicity_branch_certificates_v16 (
  certificate_id TEXT PRIMARY KEY,
  partition_id TEXT NOT NULL,
  branch_condition TEXT NOT NULL,
  conclusion TEXT NOT NULL,
  internal_obligations_json TEXT NOT NULL,
  imported_obligations_json TEXT NOT NULL,
  conditional_not_realized_fact INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  FOREIGN KEY (partition_id) REFERENCES multiplicity_case_partitions_v16(partition_id)
);

CREATE TABLE multiplicity_case_partitions_v16 (
  partition_id TEXT PRIMARY KEY,
  theorem_hypothesis TEXT NOT NULL,
  good_case TEXT NOT NULL,
  residual_case TEXT NOT NULL,
  mutually_exclusive INTEGER NOT NULL,
  exhaustive_under_hypothesis INTEGER NOT NULL,
  ordinary_branch_facts_asserted INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE multiplicity_counterfactuals_v8 (
  test_id TEXT PRIMARY KEY,
  omitted_or_changed_condition TEXT NOT NULL,
  full_dimension INTEGER NOT NULL,
  plus_dimension INTEGER NOT NULL,
  minus_dimension INTEGER NOT NULL,
  expected_behavior TEXT NOT NULL,
  pass INTEGER NOT NULL,
  interpretation TEXT NOT NULL
);

CREATE TABLE multiplicity_fiber_certificates_v15(certificate_id TEXT PRIMARY KEY,level_n INTEGER,residual_prime INTEGER,maximal_ideal_profile TEXT,full_fiber_dimension INTEGER,plus_fiber_dimension INTEGER,minus_fiber_dimension INTEGER,expected_full_dimension INTEGER,expected_sign_dimension INTEGER,irreducible INTEGER,non_eisenstein INTEGER,theorem_scope TEXT,pass INTEGER,status TEXT);

CREATE TABLE multiplicity_one_obligations_v8 (
  obligation_id TEXT PRIMARY KEY,
  stage_order INTEGER NOT NULL,
  title TEXT NOT NULL,
  statement TEXT NOT NULL,
  status TEXT NOT NULL,
  witness_table TEXT,
  source_id TEXT,
  load_bearing INTEGER NOT NULL,
  exact_remaining_frontier TEXT NOT NULL
);

CREATE TABLE multiplicity_one_profiles (
  profile_id TEXT PRIMARY KEY,
  residual_prime INTEGER NOT NULL,
  level_n INTEGER NOT NULL,
  localized_eigenspace_dimension INTEGER,
  expected_dimension INTEGER NOT NULL,
  multiplicity_one_pass INTEGER,
  status TEXT NOT NULL,
  source_id TEXT,
  notes TEXT
);

CREATE TABLE multiplicity_parent_audit_v16 (
  edge_id TEXT PRIMARY KEY,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  good_case_compiler_internalized INTEGER NOT NULL,
  residual_case_router_internalized INTEGER NOT NULL,
  proof_by_cases_internalized INTEGER NOT NULL,
  parent_removed INTEGER NOT NULL,
  child_import_count INTEGER NOT NULL,
  theorem_content_fully_internalized INTEGER NOT NULL,
  status TEXT NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE multiplicity_two_counterfactuals_v16 (
  test_id TEXT PRIMARY KEY,
  changed_or_missing_hypothesis TEXT NOT NULL,
  residual_irreducible INTEGER NOT NULL,
  theorem_case_applicable INTEGER NOT NULL,
  qexp_line_dimension INTEGER NOT NULL,
  connected_dimension INTEGER NOT NULL,
  inferred_torsion_dimension INTEGER NOT NULL,
  theorem_conclusion INTEGER NOT NULL,
  expected_conclusion INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  interpretation TEXT NOT NULL
);

CREATE TABLE multiplicity_two_obligations_v16 (
  obligation_id TEXT PRIMARY KEY,
  stage_order INTEGER NOT NULL,
  branch TEXT NOT NULL,
  title TEXT NOT NULL,
  statement TEXT NOT NULL,
  status TEXT NOT NULL,
  witness_table TEXT,
  source_id TEXT,
  load_bearing INTEGER NOT NULL,
  exact_frontier TEXT NOT NULL
);

CREATE TABLE multiplicity_two_parent_certificates_v16 (
  certificate_id TEXT PRIMARY KEY,
  parent_fact TEXT NOT NULL,
  partition_id TEXT NOT NULL,
  good_branch_certificate TEXT NOT NULL,
  residual_branch_certificate TEXT NOT NULL,
  parent_is_raw_import INTEGER NOT NULL,
  parent_derived_by_cases INTEGER NOT NULL,
  internal_child_count INTEGER NOT NULL,
  imported_child_count INTEGER NOT NULL,
  status TEXT NOT NULL,
  remaining_imports_json TEXT NOT NULL
);

CREATE TABLE n_structure_compatibility_v12 (
  check_id TEXT PRIMARY KEY,
  system_id TEXT NOT NULL,
  source_stage INTEGER NOT NULL,
  target_stage INTEGER NOT NULL,
  diamond_truncation_pass INTEGER NOT NULL,
  deformation_map_compatible INTEGER NOT NULL,
  hecke_map_compatible INTEGER NOT NULL,
  augmentation_compatible INTEGER NOT NULL,
  compiler_contract_compatible INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE nakayama_freeness_certificates_v15(certificate_id TEXT PRIMARY KEY,ring_model TEXT,module_model TEXT,target_rank INTEGER,generic_rank INTEGER,fiber_dimension INTEGER,generator_count INTEGER,ring_o_torsion_free INTEGER,module_o_torsion_free INTEGER,map_surjective INTEGER,kernel_generic_zero INTEGER,kernel_o_torsion_free INTEGER,map_injective INTEGER,free_rank_conclusion INTEGER,proof_rule TEXT,pass INTEGER);

CREATE TABLE neron_component_group_witnesses (
  model_id TEXT PRIMARY KEY,
  smith_diagonal_json TEXT NOT NULL,
  invariant_factors_json TEXT NOT NULL,
  component_group_order INTEGER NOT NULL,
  expected_order INTEGER,
  order_match_pass INTEGER NOT NULL,
  theorem_status TEXT NOT NULL,
  source_id TEXT,
  FOREIGN KEY (model_id) REFERENCES modular_integral_models(model_id)
);

CREATE TABLE nine_parent_audit_v21 (
  edge_order INTEGER PRIMARY KEY,
  edge_id TEXT NOT NULL,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  parent_removed INTEGER NOT NULL,
  replacement_kernel_id TEXT NOT NULL,
  kernel_shared_with_parent_count INTEGER NOT NULL,
  theorem_content_fully_internalized INTEGER NOT NULL,
  status TEXT NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE normalization_residue_witnesses (
  witness_id INTEGER PRIMARY KEY AUTOINCREMENT,
  exponent_p INTEGER NOT NULL,
  modulus INTEGER NOT NULL,
  raw_a INTEGER NOT NULL,
  raw_b INTEGER NOT NULL,
  raw_c INTEGER NOT NULL,
  equation_holds_mod INTEGER NOT NULL,
  even_count INTEGER NOT NULL,
  normalized_a INTEGER NOT NULL,
  normalized_b INTEGER NOT NULL,
  normalized_c INTEGER NOT NULL,
  normalized_b_even INTEGER NOT NULL,
  normalized_a_mod4 INTEGER NOT NULL,
  b_power_divisible_by_32 INTEGER NOT NULL,
  a_power_plus_one_divisible_by_4 INTEGER NOT NULL,
  normalization_pass INTEGER NOT NULL
);

CREATE TABLE normalized_frey_models (
  model_id TEXT PRIMARY KEY,
  base_a INTEGER NOT NULL,
  base_b INTEGER NOT NULL,
  exponent_p INTEGER NOT NULL,
  power_a TEXT NOT NULL,
  power_b TEXT NOT NULL,
  power_c_signed TEXT NOT NULL,
  pairwise_coprime INTEGER NOT NULL,
  condition_32_divides_b_power INTEGER NOT NULL,
  condition_4_divides_a_power_plus_1 INTEGER NOT NULL,
  change_x TEXT NOT NULL,
  change_y TEXT NOT NULL,
  minimal_a1 INTEGER NOT NULL,
  minimal_a2 TEXT NOT NULL,
  minimal_a3 INTEGER NOT NULL,
  minimal_a4 TEXT NOT NULL,
  minimal_a6 INTEGER NOT NULL,
  original_discriminant TEXT NOT NULL,
  minimal_discriminant TEXT NOT NULL,
  minimal_c4 TEXT NOT NULL,
  minimal_c6 TEXT NOT NULL,
  v2_minimal_discriminant INTEGER NOT NULL,
  v2_minimal_c4 INTEGER NOT NULL,
  integral_change_pass INTEGER NOT NULL,
  discriminant_scaling_pass INTEGER NOT NULL,
  minimal_at_2_pass INTEGER NOT NULL,
  multiplicative_at_2_pass INTEGER NOT NULL,
  sample_semistable_pass INTEGER NOT NULL,
  notes TEXT
);

CREATE TABLE numerical_criterion_cases(case_id TEXT PRIMARY KEY,prime_p INTEGER,tangent_dim_r INTEGER,tangent_dim_t INTEGER,length_r INTEGER,length_t INTEGER,surjective INTEGER,complete_intersection_r INTEGER,complete_intersection_t INTEGER,tangent_match INTEGER,length_match INTEGER,isomorphism_certified INTEGER,role TEXT);

CREATE TABLE numerical_criterion_parent_audit_v20 (
  edge_id TEXT PRIMARY KEY,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  faithful_module_lemma_internalized INTEGER NOT NULL,
  patching_output_reused INTEGER NOT NULL,
  parent_removed INTEGER NOT NULL,
  child_import_count INTEGER NOT NULL,
  theorem_content_fully_internalized_for_live_trace INTEGER NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE old_new_intersection_checks (
  check_id TEXT PRIMARY KEY,
  residual_prime INTEGER NOT NULL,
  ambient_dimension INTEGER NOT NULL,
  old_map_matrix_json TEXT NOT NULL,
  new_relation_matrix_json TEXT NOT NULL,
  old_image_dimension INTEGER NOT NULL,
  new_kernel_dimension INTEGER NOT NULL,
  intersection_dimension INTEGER NOT NULL,
  expected_intersection_dimension INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  role TEXT NOT NULL
);

CREATE TABLE omnibus_parent_replacements_v10 (
  parent_id TEXT PRIMARY KEY,
  old_proof_fact TEXT NOT NULL,
  old_derivation_kind TEXT NOT NULL,
  new_derivation_kind TEXT NOT NULL,
  child_obligation_table TEXT NOT NULL,
  child_count INTEGER NOT NULL,
  internal_children INTEGER NOT NULL,
  imported_children INTEGER NOT NULL,
  unresolved_children INTEGER NOT NULL,
  removed_as_omnibus_import INTEGER NOT NULL,
  theorem_content_fully_internalized INTEGER NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE one_step_lowering_runs (
  run_id TEXT PRIMARY KEY,
  residual_prime INTEGER NOT NULL,
  level_before INTEGER NOT NULL,
  removed_prime_q INTEGER NOT NULL,
  level_after INTEGER NOT NULL,
  degeneracy_kernel_witness INTEGER NOT NULL,
  component_specialization_witness INTEGER NOT NULL,
  old_new_intersection_witness INTEGER NOT NULL,
  eigenclass_lift_witness INTEGER NOT NULL,
  imported_bridge_used INTEGER NOT NULL,
  lower_level_form_derived INTEGER NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE ordinary_filtration_certificates_v14 (
 certificate_id TEXT PRIMARY KEY, residual_prime INTEGER NOT NULL, stage_count INTEGER NOT NULL,
 all_stage_projectors_pass INTEGER NOT NULL, unit_root_quotient_rank INTEGER NOT NULL,
 complementary_rank INTEGER NOT NULL, compatible_filtration INTEGER NOT NULL,
 local_model TEXT NOT NULL, pass INTEGER NOT NULL);

CREATE TABLE ordinary_projector_certificates_v14 (
 stage_id TEXT PRIMARY KEY, frobenius_matrix_json TEXT NOT NULL, projector_json TEXT NOT NULL,
 projector_idempotent INTEGER NOT NULL, projector_rank_mod_p INTEGER NOT NULL,
 unit_root_eigenspace_pass INTEGER NOT NULL, complementary_eigenspace_pass INTEGER NOT NULL,
 pass INTEGER NOT NULL);

CREATE TABLE ordinary_unit_root_stages_v14 (
 stage_id TEXT PRIMARY KEY, residual_prime INTEGER NOT NULL, precision_n INTEGER NOT NULL,
 modulus INTEGER NOT NULL, a_p INTEGER NOT NULL, unit_root INTEGER NOT NULL,
 nonunit_root INTEGER NOT NULL, root_sum_pass INTEGER NOT NULL, root_product_pass INTEGER NOT NULL,
 root_difference_unit INTEGER NOT NULL, pass INTEGER NOT NULL);

CREATE TABLE parent_edge_audit_v15(edge_id TEXT PRIMARY KEY,previous_status TEXT,current_status TEXT,nakayama_compiler_internalized INTEGER,sign_compiler_internalized INTEGER,comparison_compiler_internalized INTEGER,parent_removed INTEGER,child_import_count INTEGER,status TEXT,next_target TEXT);

CREATE TABLE parent_kernel_dependencies_v21 (
  parent_edge_id TEXT PRIMARY KEY,
  parent_fact TEXT NOT NULL,
  kernel_id TEXT NOT NULL,
  internal_antecedents_json TEXT NOT NULL,
  parent_derivation_kind TEXT NOT NULL,
  direct_parent_import_removed INTEGER NOT NULL,
  theorem_content_fully_internalized INTEGER NOT NULL,
  FOREIGN KEY(kernel_id) REFERENCES foundation_kernels_v21(kernel_id)
);

CREATE TABLE patched_system_certificates_v10 (
  system_id TEXT PRIMARY KEY,
  prime_p INTEGER NOT NULL,
  variable_count INTEGER NOT NULL,
  max_stage INTEGER NOT NULL,
  transition_count INTEGER NOT NULL,
  all_transitions_pass INTEGER NOT NULL,
  stage_lengths_json TEXT NOT NULL,
  inverse_limit_description TEXT NOT NULL,
  actual_arithmetic_module_adapter_status TEXT NOT NULL,
  patching_theorem_status TEXT NOT NULL
);

CREATE TABLE patching_inverse_systems(system_id TEXT PRIMARY KEY,prime_p INTEGER,variable_count INTEGER,max_stage INTEGER,stage_lengths_json TEXT,transition_surjective INTEGER,inverse_limit_description TEXT,patched_ring_dimension INTEGER,patched_module_rank INTEGER);

CREATE TABLE patching_profiles(
 profile_id TEXT PRIMARY KEY, curve_id TEXT NOT NULL, residual_prime INTEGER NOT NULL,
 power_n INTEGER NOT NULL, selmer_dimension INTEGER NOT NULL,
 selected_primes_json TEXT NOT NULL, auxiliary_group_order TEXT NOT NULL,
 variables_added INTEGER NOT NULL, relations_balanced INTEGER NOT NULL,
 dimension_balance_pass INTEGER NOT NULL, theorem_status TEXT NOT NULL, notes TEXT);

CREATE TABLE patching_transition_checks(check_id TEXT PRIMARY KEY,system_id TEXT,stage_from INTEGER,stage_to INTEGER,source_length INTEGER,target_length INTEGER,kernel_length INTEGER,expected_kernel_length INTEGER,pass INTEGER);

CREATE TABLE perfect_pairing_certificates_v15(certificate_id TEXT PRIMARY KEY,profile_id TEXT,residual_prime INTEGER,precision_n INTEGER,modulus INTEGER,pairing_matrix_json TEXT,determinant INTEGER,determinant_unit INTEGER,alternating INTEGER,hecke_balanced INTEGER,self_dual INTEGER,pass INTEGER);

CREATE TABLE pgl2f3_classes_v10 (
  projective_class_id INTEGER PRIMARY KEY,
  representative_json TEXT NOT NULL,
  permutation_json TEXT NOT NULL,
  permutation_order INTEGER NOT NULL,
  determinant_squareclass INTEGER NOT NULL,
  faithful_action INTEGER NOT NULL
);

CREATE TABLE pgl2f3_subgroups_v10 (
  subgroup_id INTEGER PRIMARY KEY,
  subgroup_order INTEGER NOT NULL,
  element_ids_json TEXT NOT NULL,
  derived_series_orders_json TEXT NOT NULL,
  derived_length INTEGER NOT NULL,
  solvable INTEGER NOT NULL,
  transitive_on_p1 INTEGER NOT NULL
);

CREATE TABLE picard_component_representatives_v6 (
  certificate_id TEXT NOT NULL,
  class_index INTEGER NOT NULL,
  multidegree_vector_json TEXT NOT NULL,
  canonical_residue INTEGER NOT NULL,
  identity_class INTEGER NOT NULL,
  PRIMARY KEY (certificate_id,class_index),
  FOREIGN KEY (certificate_id) REFERENCES raynaud_component_certificates_v6(certificate_id)
);

CREATE TABLE poitou_tate_profiles_v10 (
  profile_id TEXT PRIMARY KEY,
  problem_id TEXT NOT NULL,
  global_h1_symbol TEXT NOT NULL,
  local_sum_symbol TEXT NOT NULL,
  dual_h1_symbol TEXT NOT NULL,
  balance_formula TEXT NOT NULL,
  finite_balance_controls_pass INTEGER NOT NULL,
  theorem_status TEXT NOT NULL,
  source_id TEXT
);

CREATE TABLE prime_count_density_stages_v19 (
  stage_id TEXT PRIMARY KEY,
  polynomial TEXT NOT NULL,
  prime_bound INTEGER NOT NULL,
  unramified_prime_count INTEGER NOT NULL,
  class_counts_json TEXT NOT NULL,
  empirical_densities_json TEXT NOT NULL,
  expected_densities_json TEXT NOT NULL,
  max_absolute_error TEXT NOT NULL,
  every_class_seen INTEGER NOT NULL,
  finite_evidence_pass INTEGER NOT NULL
);

CREATE TABLE prime_distribution_contracts_v21 (
  certificate_id TEXT PRIMARY KEY,
  finite_quotient TEXT NOT NULL,
  class_count INTEGER NOT NULL,
  class_table_complete INTEGER NOT NULL,
  prime_count_stage_count INTEGER NOT NULL,
  all_classes_seen INTEGER NOT NULL,
  empirical_density_pass INTEGER NOT NULL,
  analytic_kernel_input INTEGER NOT NULL,
  class_coverage_derived INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE proof_by_cases_certificates_v12 (
  certificate_id TEXT PRIMARY KEY,
  partition_id TEXT NOT NULL,
  positive_certificate TEXT NOT NULL,
  negative_certificate TEXT NOT NULL,
  common_conclusion TEXT NOT NULL,
  branch_conditions_exhaustive INTEGER NOT NULL,
  no_simultaneous_realized_branches INTEGER NOT NULL,
  proof_by_cases_pass INTEGER NOT NULL,
  FOREIGN KEY (partition_id) REFERENCES case_partitions_v12(partition_id)
);

CREATE TABLE proof_trace (
  step_no INTEGER PRIMARY KEY,
  rule_id TEXT,
  derived_fact TEXT NOT NULL,
  antecedents_json TEXT NOT NULL,
  derivation_kind TEXT NOT NULL,
  contradiction INTEGER NOT NULL DEFAULT 0,
  notes TEXT,
  FOREIGN KEY (rule_id) REFERENCES implication_rules(rule_id)
);

CREATE TABLE proof_trace_revisions_v10 (
  revision_id TEXT PRIMARY KEY,
  previous_trace_hash TEXT NOT NULL,
  revised_trace_hash TEXT NOT NULL,
  previous_step_count INTEGER NOT NULL,
  revised_step_count INTEGER NOT NULL,
  residual_parent_replaced INTEGER NOT NULL,
  rt_parent_replaced INTEGER NOT NULL,
  contradiction_preserved INTEGER NOT NULL,
  recorded_at TEXT NOT NULL
);

CREATE TABLE proof_trace_revisions_v11 (
  revision_id TEXT PRIMARY KEY,
  previous_trace_hash TEXT NOT NULL,
  revised_trace_hash TEXT NOT NULL,
  previous_step_count INTEGER NOT NULL,
  revised_step_count INTEGER NOT NULL,
  patching_parent_replaced INTEGER NOT NULL,
  contradiction_preserved INTEGER NOT NULL,
  recorded_at TEXT NOT NULL
);

CREATE TABLE proof_trace_revisions_v12 (
  revision_id TEXT PRIMARY KEY,
  previous_trace_hash TEXT NOT NULL,
  revised_trace_hash TEXT NOT NULL,
  previous_step_count INTEGER NOT NULL,
  revised_step_count INTEGER NOT NULL,
  proof_by_cases_repaired INTEGER NOT NULL,
  stage_freeness_parent_replaced INTEGER NOT NULL,
  arithmetic_parent_replaced INTEGER NOT NULL,
  rt_surjection_parent_replaced INTEGER NOT NULL,
  contradiction_preserved INTEGER NOT NULL,
  recorded_at TEXT NOT NULL
);

CREATE TABLE proof_trace_revisions_v13 (
  revision_id TEXT PRIMARY KEY,
  previous_trace_hash TEXT NOT NULL,
  revised_trace_hash TEXT NOT NULL,
  previous_step_count INTEGER NOT NULL,
  revised_step_count INTEGER NOT NULL,
  hecke_parent_replaced INTEGER NOT NULL,
  contradiction_preserved INTEGER NOT NULL,
  recorded_at TEXT NOT NULL
);

CREATE TABLE proof_trace_revisions_v14 (
 revision_id TEXT PRIMARY KEY, previous_trace_hash TEXT NOT NULL, revised_trace_hash TEXT NOT NULL,
 previous_step_count INTEGER NOT NULL, revised_step_count INTEGER NOT NULL,
 pseudocharacter_parent_replaced INTEGER NOT NULL, local_global_parent_replaced INTEGER NOT NULL,
 contradiction_preserved INTEGER NOT NULL, recorded_at TEXT NOT NULL);

CREATE TABLE proof_trace_revisions_v15(revision_id TEXT PRIMARY KEY,previous_trace_hash TEXT,revised_trace_hash TEXT,previous_step_count INTEGER,revised_step_count INTEGER,etale_parent_replaced INTEGER,rank_one_parent_replaced INTEGER,contradiction_preserved INTEGER,recorded_at TEXT);

CREATE TABLE proof_trace_revisions_v16 (
  revision_id TEXT PRIMARY KEY,
  previous_trace_hash TEXT NOT NULL,
  revised_trace_hash TEXT NOT NULL,
  previous_step_count INTEGER NOT NULL,
  revised_step_count INTEGER NOT NULL,
  multiplicity_parent_replaced INTEGER NOT NULL,
  contradiction_preserved INTEGER NOT NULL,
  recorded_at TEXT NOT NULL
);

CREATE TABLE proof_trace_revisions_v17 (
  revision_id TEXT PRIMARY KEY,
  previous_trace_hash TEXT NOT NULL,
  revised_trace_hash TEXT NOT NULL,
  previous_step_count INTEGER NOT NULL,
  revised_step_count INTEGER NOT NULL,
  five_parents_replaced INTEGER NOT NULL,
  contradiction_preserved INTEGER NOT NULL,
  recorded_at TEXT NOT NULL
);

CREATE TABLE proof_trace_revisions_v18 (
  revision_id TEXT PRIMARY KEY,
  previous_trace_hash TEXT NOT NULL,
  revised_trace_hash TEXT NOT NULL,
  previous_step_count INTEGER NOT NULL,
  revised_step_count INTEGER NOT NULL,
  second_five_parents_replaced INTEGER NOT NULL,
  ten_edge_batch_complete INTEGER NOT NULL,
  contradiction_preserved INTEGER NOT NULL,
  recorded_at TEXT NOT NULL
);

CREATE TABLE proof_trace_revisions_v19 (
  revision_id TEXT PRIMARY KEY,
  previous_trace_hash TEXT NOT NULL,
  revised_trace_hash TEXT NOT NULL,
  previous_step_count INTEGER NOT NULL,
  revised_step_count INTEGER NOT NULL,
  five_parents_replaced INTEGER NOT NULL,
  contradiction_preserved INTEGER NOT NULL,
  recorded_at TEXT NOT NULL
);

CREATE TABLE proof_trace_revisions_v20 (
  revision_id TEXT PRIMARY KEY,
  previous_trace_hash TEXT NOT NULL,
  revised_trace_hash TEXT NOT NULL,
  previous_step_count INTEGER NOT NULL,
  revised_step_count INTEGER NOT NULL,
  five_parents_replaced INTEGER NOT NULL,
  active_imports_before INTEGER NOT NULL,
  active_imports_after INTEGER NOT NULL,
  contradiction_preserved INTEGER NOT NULL,
  recorded_at TEXT NOT NULL
);

CREATE TABLE proof_trace_revisions_v21 (
  revision_id TEXT PRIMARY KEY,
  previous_trace_hash TEXT NOT NULL,
  revised_trace_hash TEXT NOT NULL,
  previous_step_count INTEGER NOT NULL,
  revised_step_count INTEGER NOT NULL,
  nine_parents_replaced INTEGER NOT NULL,
  active_imports_before INTEGER NOT NULL,
  active_imports_after INTEGER NOT NULL,
  contradiction_preserved INTEGER NOT NULL,
  recorded_at TEXT NOT NULL
);

CREATE TABLE pseudocharacter_contracts_v13 (
  contract_id TEXT PRIMARY KEY,
  dimension INTEGER NOT NULL,
  coefficient_ring_contract TEXT NOT NULL,
  group_contract TEXT NOT NULL,
  trace_identities_json TEXT NOT NULL,
  determinant_identities_json TEXT NOT NULL,
  absolute_irreducibility_contract TEXT NOT NULL,
  output_contract TEXT NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE pseudocharacter_counterfactuals_v13 (
  test_id TEXT PRIMARY KEY,
  model_description TEXT NOT NULL,
  residual_trace_pairing_rank INTEGER NOT NULL,
  pseudocharacter_identity_pass INTEGER NOT NULL,
  matrix_unit_certificate_present INTEGER NOT NULL,
  compiler_accept INTEGER NOT NULL,
  expected_accept INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  interpretation TEXT NOT NULL
);

CREATE TABLE pseudocharacter_stages_v13 (
  stage_id TEXT PRIMARY KEY,
  group_id TEXT NOT NULL,
  prime_p INTEGER NOT NULL,
  precision_n INTEGER NOT NULL,
  modulus INTEGER NOT NULL,
  trace_values_json TEXT NOT NULL,
  determinant_values_json TEXT NOT NULL,
  identity_failures INTEGER NOT NULL,
  centrality_failures INTEGER NOT NULL,
  determinant_failures INTEGER NOT NULL,
  pseudocharacter_failures INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  FOREIGN KEY (group_id) REFERENCES finite_group_models_v13(group_id)
);

CREATE TABLE qexp_duality_models_v16 (
  model_id TEXT PRIMARY KEY,
  field_characteristic INTEGER NOT NULL,
  local_algebra TEXT NOT NULL,
  algebra_dimension INTEGER NOT NULL,
  dual_dimension INTEGER NOT NULL,
  maximal_ideal_generators INTEGER NOT NULL,
  action_matrix_json TEXT NOT NULL,
  m_torsion_dimension INTEGER NOT NULL,
  residue_field_dimension INTEGER NOT NULL,
  perfect_pairing INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE qexp_eigenline_certificates_v16 (
  certificate_id TEXT PRIMARY KEY,
  level_n INTEGER NOT NULL,
  residual_prime INTEGER NOT NULL,
  maximal_ideal_profile TEXT NOT NULL,
  finite_algebra_model TEXT,
  qexp_pairing_present INTEGER NOT NULL,
  non_eisenstein INTEGER NOT NULL,
  normalized_packet_present INTEGER NOT NULL,
  eigendifferential_dimension INTEGER NOT NULL,
  expected_dimension INTEGER NOT NULL,
  status TEXT NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE rank_one_lift_certificates_v9 (
  certificate_id TEXT PRIMARY KEY,
  algebra_id TEXT NOT NULL,
  residual_prime INTEGER NOT NULL,
  module_rank INTEGER NOT NULL,
  residual_vector_json TEXT NOT NULL,
  integral_lift_vector_json TEXT NOT NULL,
  operator_count INTEGER NOT NULL,
  all_actions_scalar INTEGER NOT NULL,
  residual_character_lifts INTEGER NOT NULL,
  unique_up_to_unit INTEGER NOT NULL,
  finite_extension_required INTEGER NOT NULL,
  lift_pass INTEGER NOT NULL,
  proof_rule TEXT NOT NULL,
  FOREIGN KEY (algebra_id) REFERENCES localized_hecke_algebras_v9(algebra_id)
);

CREATE TABLE rank_two_etale_module_certificates_v15(certificate_id TEXT PRIMARY KEY,level_n INTEGER,residual_prime INTEGER,rational_rank_certificate TEXT,multiplicity_fiber_certificate TEXT,nakayama_certificate TEXT,comparison_certificate TEXT,module_free_rank INTEGER,galois_action_commutes_with_hecke INTEGER,good_prime_relation_compiler_present INTEGER,parent_fact_derived INTEGER,direct_parent_import_used INTEGER,status TEXT);

CREATE TABLE rational_hecke_rank_certificates_v15(certificate_id TEXT PRIMARY KEY,level_n INTEGER,genus_x0 INTEGER,hecke_dimension INTEGER,homology_dimension INTEGER,expected_ratio INTEGER,observed_ratio INTEGER,rational_multiplicity_one INTEGER,pass INTEGER);

CREATE TABLE rational_symbol_reduction_checks_v7 (
  check_id TEXT PRIMARY KEY,
  level_n INTEGER NOT NULL,
  residual_prime INTEGER NOT NULL,
  source_cusp TEXT NOT NULL,
  target_cusp TEXT NOT NULL,
  path_length INTEGER NOT NULL,
  vector_json TEXT NOT NULL,
  boundary_expected_json TEXT NOT NULL,
  boundary_observed_json TEXT NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE raynaud_complexes_v6 (
  complex_id TEXT PRIMARY KEY,
  model_id TEXT NOT NULL,
  component_labels_json TEXT NOT NULL,
  multiplicities_json TEXT NOT NULL,
  node_weights_json TEXT NOT NULL,
  intersection_matrix_json TEXT NOT NULL,
  total_fiber_vector_json TEXT NOT NULL,
  degree_row_json TEXT NOT NULL,
  degree_zero_basis_json TEXT NOT NULL,
  a_after_i_zero INTEGER NOT NULL,
  b_after_a_zero INTEGER NOT NULL,
  kernel_rank INTEGER NOT NULL,
  image_rank INTEGER NOT NULL,
  theorem_contract TEXT NOT NULL,
  source_id TEXT
);

CREATE TABLE raynaud_component_certificates_v6 (
  certificate_id TEXT PRIMARY KEY,
  complex_id TEXT NOT NULL,
  quotient_matrix_json TEXT NOT NULL,
  smith_diagonal_json TEXT NOT NULL,
  invariant_factors_json TEXT NOT NULL,
  component_group_order INTEGER NOT NULL,
  expected_order INTEGER,
  exactness_pass INTEGER NOT NULL,
  order_match_pass INTEGER NOT NULL,
  adapter_status TEXT NOT NULL,
  valid_from_loop INTEGER NOT NULL,
  recorded_at TEXT NOT NULL,
  FOREIGN KEY (complex_id) REFERENCES raynaud_complexes_v6(complex_id)
);

CREATE TABLE reconstructed_representation_stages_v13 (
  stage_id TEXT PRIMARY KEY,
  reconstructed_matrices_json TEXT NOT NULL,
  group_law_failure_count INTEGER NOT NULL,
  trace_failure_count INTEGER NOT NULL,
  determinant_failure_count INTEGER NOT NULL,
  representation_dimension INTEGER NOT NULL,
  compiler_used TEXT NOT NULL,
  pass INTEGER NOT NULL,
  FOREIGN KEY (stage_id) REFERENCES pseudocharacter_stages_v13(stage_id)
);

CREATE TABLE reduction_graphs (
  graph_id TEXT PRIMARY KEY,
  vertex_count INTEGER NOT NULL,
  edges_json TEXT NOT NULL,
  connected INTEGER NOT NULL,
  reduced_laplacian_json TEXT NOT NULL,
  spanning_tree_count INTEGER NOT NULL,
  residual_prime INTEGER NOT NULL,
  role TEXT NOT NULL
);

CREATE TABLE representation_stage_compatibility_v13 (
  check_id TEXT PRIMARY KEY,
  prime_p INTEGER NOT NULL,
  high_precision INTEGER NOT NULL,
  low_precision INTEGER NOT NULL,
  trace_reduction_pass INTEGER NOT NULL,
  determinant_reduction_pass INTEGER NOT NULL,
  matrix_unit_reduction_pass INTEGER NOT NULL,
  representation_reduction_pass INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE residual_congruence_witnesses (
  curve_id TEXT NOT NULL,
  form_id TEXT NOT NULL,
  residual_prime INTEGER NOT NULL,
  frobenius_prime INTEGER NOT NULL,
  curve_trace_mod_p INTEGER NOT NULL,
  form_trace_mod_p INTEGER NOT NULL,
  determinant_mod_p INTEGER NOT NULL,
  trace_congruence_pass INTEGER NOT NULL,
  determinant_profile_pass INTEGER NOT NULL,
  PRIMARY KEY (curve_id, form_id, residual_prime, frobenius_prime)
);

CREATE TABLE residual_modularity_branch_traces_v10 (
  branch_id TEXT NOT NULL,
  step_no INTEGER NOT NULL,
  derived_fact TEXT NOT NULL,
  derivation_kind TEXT NOT NULL,
  imported INTEGER NOT NULL,
  source_id TEXT,
  terminal INTEGER NOT NULL,
  PRIMARY KEY (branch_id,step_no)
);

CREATE TABLE residual_modularity_obligations_v10 (
  obligation_id TEXT PRIMARY KEY,
  stage_order INTEGER NOT NULL,
  branch TEXT NOT NULL,
  title TEXT NOT NULL,
  statement TEXT NOT NULL,
  status TEXT NOT NULL,
  witness_table TEXT,
  source_id TEXT,
  load_bearing INTEGER NOT NULL,
  exact_frontier TEXT NOT NULL
);

CREATE TABLE residual_modularity_parent_certificates_v10 (
  certificate_id TEXT PRIMARY KEY,
  parent_fact TEXT NOT NULL,
  branch_count INTEGER NOT NULL,
  internal_child_count INTEGER NOT NULL,
  imported_child_count INTEGER NOT NULL,
  unresolved_child_count INTEGER NOT NULL,
  parent_is_raw_import INTEGER NOT NULL,
  parent_derived_from_children INTEGER NOT NULL,
  status TEXT NOT NULL,
  remaining_imports_json TEXT NOT NULL
);

CREATE TABLE residual_modularity_steps(
 step_id TEXT PRIMARY KEY, branch_name TEXT NOT NULL, step_order INTEGER NOT NULL,
 antecedent TEXT NOT NULL, consequent TEXT NOT NULL, edge_kind TEXT NOT NULL,
 source_id TEXT, witnessed INTEGER NOT NULL, imported INTEGER NOT NULL,
 branch_complete INTEGER NOT NULL, notes TEXT);

CREATE TABLE residual_prime_multiplicity_compiler_v17 (
  certificate_id TEXT PRIMARY KEY,
  profile_id TEXT NOT NULL,
  residual_prime INTEGER NOT NULL,
  level_n TEXT NOT NULL,
  exact_level_divisibility INTEGER NOT NULL,
  t_p_nonzero INTEGER NOT NULL,
  residual_irreducible INTEGER NOT NULL,
  finite_flat_parent_derived INTEGER NOT NULL,
  bad_prime_parent_derived INTEGER NOT NULL,
  qexp_line_dimension INTEGER NOT NULL,
  component_obstruction_zero INTEGER NOT NULL,
  connected_dimension INTEGER NOT NULL,
  etale_dimension INTEGER NOT NULL,
  total_dimension INTEGER NOT NULL,
  multiplicity_two_derived INTEGER NOT NULL,
  direct_parent_import_used INTEGER NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE residual_prime_multiplicity_profiles_v16 (
  profile_id TEXT PRIMARY KEY,
  level_n TEXT NOT NULL,
  residual_prime INTEGER NOT NULL,
  prime_divides_level_once INTEGER NOT NULL,
  t_p_nonzero INTEGER NOT NULL,
  residual_irreducible INTEGER NOT NULL,
  finite_flat_input_present INTEGER NOT NULL,
  bad_prime_comparison_present INTEGER NOT NULL,
  qexp_eigenline_dimension INTEGER NOT NULL,
  residual_prime_comparison_imported INTEGER NOT NULL,
  theorem_conclusion INTEGER NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE rt_direct_descent_certificates_v20 (
  certificate_id TEXT PRIMARY KEY,
  patching_system_id TEXT NOT NULL,
  universal_surjection_present INTEGER NOT NULL,
  patched_module_faithful INTEGER NOT NULL,
  direct_r_equals_t INTEGER NOT NULL,
  numerical_criterion_used INTEGER NOT NULL,
  complete_intersection_inherited INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE rt_map_certificates_v10 (
  certificate_id TEXT PRIMARY KEY,
  calibration_id TEXT NOT NULL,
  residual_prime INTEGER NOT NULL,
  stage_count INTEGER NOT NULL,
  all_trace_stages_match INTEGER NOT NULL,
  finite_trace_quotient_isomorphic INTEGER NOT NULL,
  universal_deformation_ring_identified INTEGER NOT NULL,
  hecke_galois_representation_status TEXT NOT NULL,
  status TEXT NOT NULL,
  remaining_imports_json TEXT NOT NULL
);

CREATE TABLE rt_map_diagnostics(
 map_id TEXT PRIMARY KEY, source_ring TEXT NOT NULL, target_ring TEXT NOT NULL,
 surjective INTEGER NOT NULL, source_length INTEGER, target_length INTEGER,
 cotangent_dimensions_match INTEGER NOT NULL, length_match INTEGER NOT NULL,
 isomorphism_certified INTEGER NOT NULL, notes TEXT);

CREATE TABLE rt_obligations_v10 (
  obligation_id TEXT PRIMARY KEY,
  stage_order INTEGER NOT NULL,
  title TEXT NOT NULL,
  statement TEXT NOT NULL,
  status TEXT NOT NULL,
  witness_table TEXT,
  source_id TEXT,
  load_bearing INTEGER NOT NULL,
  exact_frontier TEXT NOT NULL
);

CREATE TABLE rt_parent_certificates_v10 (
  certificate_id TEXT PRIMARY KEY,
  parent_fact TEXT NOT NULL,
  internal_child_count INTEGER NOT NULL,
  imported_child_count INTEGER NOT NULL,
  unresolved_child_count INTEGER NOT NULL,
  parent_is_raw_import INTEGER NOT NULL,
  parent_derived_from_children INTEGER NOT NULL,
  status TEXT NOT NULL,
  remaining_imports_json TEXT NOT NULL
);

CREATE TABLE rt_surjection_certificates_v12 (
  certificate_id TEXT PRIMARY KEY,
  universal_property_certificate_id TEXT NOT NULL,
  generator_coverage_certificate_id TEXT NOT NULL,
  map_constructed INTEGER NOT NULL,
  generator_coverage_pass INTEGER NOT NULL,
  surjective INTEGER NOT NULL,
  direct_parent_import_used INTEGER NOT NULL,
  status TEXT NOT NULL,
  remaining_imports_json TEXT NOT NULL
);

CREATE TABLE rt_surjection_counterfactuals_v12 (
  test_id TEXT PRIMARY KEY,
  missing_or_changed_input TEXT NOT NULL,
  map_constructed INTEGER NOT NULL,
  generator_coverage INTEGER NOT NULL,
  surjective INTEGER NOT NULL,
  expected_surjective INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  interpretation TEXT NOT NULL
);

CREATE TABLE rt_surjection_obligations_v12 (
  obligation_id TEXT PRIMARY KEY,
  stage_order INTEGER NOT NULL,
  title TEXT NOT NULL,
  statement TEXT NOT NULL,
  status TEXT NOT NULL,
  witness_table TEXT,
  source_id TEXT,
  load_bearing INTEGER NOT NULL,
  exact_frontier TEXT NOT NULL
);

CREATE TABLE rt_surjection_parent_audit_v12 (
  edge_id TEXT PRIMARY KEY,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  universal_property_internalized INTEGER NOT NULL,
  generator_coverage_internalized INTEGER NOT NULL,
  hecke_representation_internalized INTEGER NOT NULL,
  parent_removed INTEGER NOT NULL,
  child_import_count INTEGER NOT NULL,
  status TEXT NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE s3_splitting_prime_certificates_v17 (
  prime_q INTEGER PRIMARY KEY,
  polynomial TEXT NOT NULL,
  factor_degrees_json TEXT NOT NULL,
  conjugacy_class TEXT NOT NULL,
  unramified INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE schedule_revisions_v10 (
  revision_id TEXT PRIMARY KEY,
  recorded_at TEXT NOT NULL,
  user_request TEXT NOT NULL,
  previous_priority_json TEXT NOT NULL,
  revised_priority_json TEXT NOT NULL,
  status TEXT NOT NULL,
  notes TEXT
);

CREATE TABLE schedule_revisions_v11 (
  revision_id TEXT PRIMARY KEY,
  recorded_at TEXT NOT NULL,
  user_request TEXT NOT NULL,
  previous_priority_json TEXT NOT NULL,
  revised_priority_json TEXT NOT NULL,
  status TEXT NOT NULL,
  notes TEXT
);

CREATE TABLE schlessinger_compiler_cases_v21 (
  case_id TEXT PRIMARY KEY,
  residual_prime INTEGER NOT NULL,
  deformation_problem_id TEXT NOT NULL,
  absolutely_irreducible INTEGER NOT NULL,
  tangent_space_finite INTEGER NOT NULL,
  obstruction_space_typed INTEGER NOT NULL,
  fiber_product_surjectivity INTEGER NOT NULL,
  small_extension_uniqueness INTEGER NOT NULL,
  compiler_accept INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE search_runs (
  run_id TEXT PRIMARY KEY,
  exponent INTEGER NOT NULL,
  max_base INTEGER NOT NULL,
  pair_count INTEGER NOT NULL,
  solution_count INTEGER NOT NULL,
  solutions_json TEXT NOT NULL,
  elapsed_ms REAL NOT NULL,
  status TEXT NOT NULL,
  epistemic_tier TEXT NOT NULL
);

CREATE TABLE second_five_edge_audit_v18 (
  edge_order INTEGER PRIMARY KEY,
  edge_id TEXT NOT NULL,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  parent_removed INTEGER NOT NULL,
  internal_children INTEGER NOT NULL,
  imported_children INTEGER NOT NULL,
  theorem_content_fully_internalized INTEGER NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE second_five_edge_counterfactuals_v18 (
  test_id TEXT PRIMARY KEY,
  edge_scope TEXT NOT NULL,
  changed_input TEXT NOT NULL,
  parent_derived INTEGER NOT NULL,
  expected_derived INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  interpretation TEXT NOT NULL
);

CREATE TABLE second_five_edge_plan_v18 (
  edge_order INTEGER PRIMARY KEY,
  edge_id TEXT NOT NULL,
  title TEXT NOT NULL,
  loop_start INTEGER NOT NULL,
  loop_end INTEGER NOT NULL,
  acceptance_criteria TEXT NOT NULL,
  result TEXT NOT NULL
);

CREATE TABLE selmer_complexes(complex_id TEXT PRIMARY KEY,prime_p INTEGER,c0_dim INTEGER,c1_dim INTEGER,c2_dim INTEGER,d0_matrix_json TEXT,d1_matrix_json TEXT,chain_condition_pass INTEGER,h0_dim INTEGER,h1_dim INTEGER,h2_dim INTEGER,euler_characteristic INTEGER);

CREATE TABLE selmer_dimension_checks(check_id TEXT PRIMARY KEY,complex_id TEXT,local_condition_dim INTEGER,global_h1_dim INTEGER,selmer_dim INTEGER,dual_selmer_dim INTEGER,expected_balance INTEGER,observed_balance INTEGER,pass INTEGER);

CREATE TABLE shapiro_degree1_certificates_v12 (
  certificate_id TEXT PRIMARY KEY,
  prime_p INTEGER NOT NULL,
  free_group_rank INTEGER NOT NULL,
  deck_group_order INTEGER NOT NULL,
  subgroup_schreier_rank INTEGER NOT NULL,
  induced_module_dimension INTEGER NOT NULL,
  h1_subgroup_dimension INTEGER NOT NULL,
  h1_induced_dimension INTEGER NOT NULL,
  dimensions_match INTEGER NOT NULL,
  cochain_adapter_status TEXT NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE sign_projector_certificates_v15(certificate_id TEXT PRIMARY KEY,profile_id TEXT,residual_prime INTEGER,precision_n INTEGER,modulus INTEGER,two_invertible INTEGER,involution_square_identity INTEGER,plus_projector_json TEXT,minus_projector_json TEXT,projector_idempotence_pass INTEGER,orthogonality_pass INTEGER,sum_identity_pass INTEGER,residual_plus_dimension INTEGER,residual_minus_dimension INTEGER,pass INTEGER);

CREATE TABLE sign_rank_one_certificates_v15(certificate_id TEXT PRIMARY KEY,profile_id TEXT,residual_prime INTEGER,ambient_free_rank INTEGER,plus_projective INTEGER,minus_projective INTEGER,local_ring INTEGER,residual_plus_dimension INTEGER,residual_minus_dimension INTEGER,plus_free_rank INTEGER,minus_free_rank INTEGER,parent_fact_derived INTEGER,direct_parent_import_used INTEGER,proof_rule TEXT,pass INTEGER);

CREATE TABLE solvable_lift_parent_audit_v20 (
  edge_id TEXT PRIMARY KEY,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  explicit_g12_lift_internalized INTEGER NOT NULL,
  integral_reduction_internalized INTEGER NOT NULL,
  parent_removed INTEGER NOT NULL,
  child_import_count INTEGER NOT NULL,
  theorem_content_fully_internalized_for_scope INTEGER NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE sources (
  source_id TEXT PRIMARY KEY,
  citation TEXT NOT NULL,
  source_url TEXT,
  source_kind TEXT NOT NULL,
  role TEXT NOT NULL
);

CREATE TABLE special_fiber_components_v5 (
  component_id TEXT PRIMARY KEY,
  model_id TEXT NOT NULL,
  component_label TEXT NOT NULL,
  normalization_curve TEXT NOT NULL,
  multiplicity INTEGER NOT NULL,
  genus INTEGER,
  source_status TEXT NOT NULL,
  FOREIGN KEY (model_id) REFERENCES modular_integral_models(model_id)
);

CREATE TABLE specialization_contracts_v21 (
  certificate_id TEXT PRIMARY KEY,
  parameter_space TEXT NOT NULL,
  thin_profile_count INTEGER NOT NULL,
  local_constraint_count INTEGER NOT NULL,
  crt_certificate_count INTEGER NOT NULL,
  all_local_constraints_pass INTEGER NOT NULL,
  all_listed_bad_loci_avoided INTEGER NOT NULL,
  hilbert_kernel_input INTEGER NOT NULL,
  universal_specialization_derived INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE specialization_obstruction_certificates_v6 (
  obstruction_id TEXT PRIMARY KEY,
  lowering_certificate_id TEXT,
  component_certificate_id TEXT NOT NULL,
  residual_prime INTEGER NOT NULL,
  source_level INTEGER,
  removed_prime_q INTEGER,
  component_group_order INTEGER NOT NULL,
  component_p_primary_order INTEGER NOT NULL,
  all_p_torsion_specializes_to_identity INTEGER NOT NULL,
  component_obstruction_resolved INTEGER NOT NULL,
  derivation_kind TEXT NOT NULL,
  remaining_imports_json TEXT NOT NULL,
  status TEXT NOT NULL,
  FOREIGN KEY (component_certificate_id) REFERENCES raynaud_component_certificates_v6(certificate_id)
);

CREATE TABLE stabilization_polynomial_certificates_v8 (
  certificate_id TEXT PRIMARY KEY,
  level_n INTEGER NOT NULL,
  base_level INTEGER NOT NULL,
  raised_prime_q INTEGER NOT NULL,
  residual_prime INTEGER NOT NULL,
  base_aq INTEGER NOT NULL,
  polynomial TEXT NOT NULL,
  root_one INTEGER NOT NULL,
  root_two INTEGER NOT NULL,
  good_packet_dimension INTEGER NOT NULL,
  root_one_packet_dimension INTEGER NOT NULL,
  root_two_packet_dimension INTEGER NOT NULL,
  polynomial_annihilates_good_packet INTEGER NOT NULL,
  direct_sum_pass INTEGER NOT NULL,
  characteristic_polynomial TEXT NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE steinberg_weil_deligne_certificates_v14 (
 certificate_id TEXT PRIMARY KEY, residual_prime INTEGER NOT NULL, precision_n INTEGER NOT NULL,
 modulus INTEGER NOT NULL, local_prime_q INTEGER NOT NULL, u_q INTEGER NOT NULL,
 frobenius_matrix_json TEXT NOT NULL, monodromy_matrix_json TEXT NOT NULL,
 wd_relation_pass INTEGER NOT NULL, monodromy_rank INTEGER NOT NULL,
 determinant_pass INTEGER NOT NULL, local_euler_factor TEXT NOT NULL,
 u_q_factor_pass INTEGER NOT NULL, pass INTEGER NOT NULL);

CREATE TABLE sturm_bounds (
  level_n INTEGER NOT NULL,
  weight_k INTEGER NOT NULL,
  gamma0_index INTEGER NOT NULL,
  bound INTEGER NOT NULL,
  interpretation TEXT NOT NULL,
  source_id TEXT,
  PRIMARY KEY (level_n, weight_k),
  FOREIGN KEY (source_id) REFERENCES sources(source_id)
);

CREATE TABLE sturm_eigenpacket_checks_v8 (
  check_id TEXT PRIMARY KEY,
  certificate_id TEXT NOT NULL,
  n INTEGER NOT NULL,
  operator_expression TEXT NOT NULL,
  expected_stabilized_coefficient INTEGER NOT NULL,
  observed_eigenvalue INTEGER NOT NULL,
  eigenvector_pass INTEGER NOT NULL,
  within_sturm_bound INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE supersingular_base_curve_checks_v6 (
  check_id TEXT PRIMARY KEY,
  characteristic_q INTEGER NOT NULL,
  curve_equation TEXT NOT NULL,
  j_invariant TEXT NOT NULL,
  point_count INTEGER NOT NULL,
  frobenius_trace INTEGER NOT NULL,
  supersingular_by_trace INTEGER NOT NULL,
  supersingular_class_count_formula INTEGER NOT NULL,
  unique_class INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE supersingular_level_actions_v6 (
  action_id TEXT PRIMARY KEY,
  characteristic_q INTEGER NOT NULL,
  tame_level_n INTEGER NOT NULL,
  supersingular_j TEXT NOT NULL,
  projective_point_count INTEGER NOT NULL,
  automorphism_matrix_json TEXT NOT NULL,
  automorphism_order INTEGER NOT NULL,
  fixed_line_count INTEGER NOT NULL,
  orbit_count INTEGER NOT NULL,
  all_orbits_expected_size INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  source_id TEXT
);

CREATE TABLE supersingular_level_orbits_v6 (
  orbit_id TEXT PRIMARY KEY,
  action_id TEXT NOT NULL,
  orbit_index INTEGER NOT NULL,
  projective_points_json TEXT NOT NULL,
  orbit_size INTEGER NOT NULL,
  stabilizer_mod_sign INTEGER NOT NULL,
  node_weight INTEGER NOT NULL,
  coarse_supersingular_point INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  FOREIGN KEY (action_id) REFERENCES supersingular_level_actions_v6(action_id)
);

CREATE TABLE supersingular_nodes_v5 (
  node_id TEXT PRIMARY KEY,
  model_id TEXT NOT NULL,
  node_label TEXT NOT NULL,
  j_invariant_label TEXT,
  automorphism_weight INTEGER NOT NULL,
  intersection_thickness INTEGER NOT NULL,
  source_status TEXT NOT NULL,
  FOREIGN KEY (model_id) REFERENCES modular_integral_models(model_id)
);

CREATE TABLE symbolic_witnesses (
  witness_id TEXT PRIMARY KEY,
  statement TEXT NOT NULL,
  lhs TEXT NOT NULL,
  rhs TEXT NOT NULL,
  residual TEXT NOT NULL,
  pass INTEGER NOT NULL,
  witness_method TEXT NOT NULL,
  epistemic_tier TEXT NOT NULL
);

CREATE TABLE tangent_obstruction_interfaces_v10 (
  interface_id TEXT PRIMARY KEY,
  problem_id TEXT NOT NULL,
  h1_object TEXT NOT NULL,
  h2_object TEXT NOT NULL,
  selmer_object TEXT NOT NULL,
  dual_selmer_object TEXT NOT NULL,
  finite_complex_rows INTEGER NOT NULL,
  finite_complexes_all_pass INTEGER NOT NULL,
  actual_galois_cohomology_adapter_status TEXT NOT NULL
);

CREATE TABLE target_frontier_audit (
  edge_id TEXT PRIMARY KEY,
  target_name TEXT NOT NULL,
  child_obligation_count INTEGER NOT NULL,
  internally_witnessed_children INTEGER NOT NULL,
  imported_children INTEGER NOT NULL,
  contradiction_depends_on_edge INTEGER NOT NULL,
  recommended_next_loop TEXT NOT NULL
);

CREATE TABLE target_packet_reduction_checks_v9 (
  check_id TEXT PRIMARY KEY,
  lift_certificate_id TEXT NOT NULL,
  check_kind TEXT NOT NULL,
  coefficient_or_operator TEXT NOT NULL,
  integer_value INTEGER NOT NULL,
  expected_residual_value INTEGER NOT NULL,
  observed_residual_value INTEGER NOT NULL,
  within_sturm_bound INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  FOREIGN KEY (lift_certificate_id) REFERENCES rank_one_lift_certificates_v9(certificate_id)
);

CREATE TABLE tate_finite_flat_certificates_v20 (
  certificate_id TEXT PRIMARY KEY,
  residual_prime INTEGER NOT NULL,
  valuation INTEGER NOT NULL,
  valuation_mod_p INTEGER NOT NULL,
  unit_parameter TEXT NOT NULL,
  kummer_class_from_unit INTEGER NOT NULL,
  explicit_group_scheme_present INTEGER NOT NULL,
  finite_flat_derived INTEGER NOT NULL,
  converse_derived INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE tate_module_compatibility_v15(check_id TEXT PRIMARY KEY,profile_id TEXT,residual_prime INTEGER,high_precision INTEGER,low_precision INTEGER,module_reduction_pass INTEGER,involution_reduction_pass INTEGER,pairing_reduction_pass INTEGER,hecke_reduction_pass INTEGER,pass INTEGER);

CREATE TABLE tate_module_stages_v15(stage_id TEXT PRIMARY KEY,profile_id TEXT,level_n INTEGER,residual_prime INTEGER,precision_n INTEGER,modulus INTEGER,hecke_algebra_model TEXT,module_rank INTEGER,module_cardinality_log_p INTEGER,plus_rank INTEGER,minus_rank INTEGER,involution_matrix_json TEXT,pairing_matrix_json TEXT,pairing_determinant_unit INTEGER,hecke_action_scalar INTEGER,pass INTEGER);

CREATE TABLE tate_series_coefficients(
 series_name TEXT NOT NULL, exponent INTEGER NOT NULL, coefficient TEXT NOT NULL,
 derivation TEXT NOT NULL, check_pass INTEGER NOT NULL,
 PRIMARY KEY(series_name,exponent));

CREATE TABLE tate_torsion_classes(
 residual_prime INTEGER NOT NULL, valuation_v INTEGER NOT NULL, class_name TEXT NOT NULL,
 coordinate TEXT NOT NULL, predicted_ramification_index INTEGER NOT NULL,
 unramified_over_max_unramified INTEGER NOT NULL, derivation TEXT NOT NULL,
 PRIMARY KEY(residual_prime,valuation_v,class_name));

CREATE TABLE taylor_wiles_primes(
 profile_id TEXT NOT NULL, curve_id TEXT NOT NULL, residual_prime INTEGER NOT NULL,
 power_n INTEGER NOT NULL, auxiliary_prime_q INTEGER NOT NULL, trace_aq INTEGER NOT NULL,
 q_congruence_pass INTEGER NOT NULL, frobenius_discriminant_mod_p INTEGER NOT NULL,
 split_distinct_pass INTEGER NOT NULL, good_reduction INTEGER NOT NULL,
 PRIMARY KEY(profile_id,auxiliary_prime_q));

CREATE TABLE ten_edge_batch_audit_v18 (
  batch_id TEXT PRIMARY KEY,
  first_release TEXT NOT NULL,
  second_release TEXT NOT NULL,
  total_parent_imports_removed INTEGER NOT NULL,
  total_replacement_child_imports INTEGER NOT NULL,
  active_imports_before INTEGER NOT NULL,
  active_imports_after INTEGER NOT NULL,
  contradiction_preserved INTEGER NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE theorem_edge_refinements(parent_edge_id TEXT,child_edge_id TEXT,child_title TEXT,child_status TEXT,witness_table TEXT,source_id TEXT,load_bearing INTEGER,PRIMARY KEY(parent_edge_id,child_edge_id));

CREATE TABLE theorem_nodes (
  node_id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  statement TEXT NOT NULL,
  node_kind TEXT NOT NULL,
  status TEXT NOT NULL,
  assumptions_json TEXT NOT NULL,
  source_id TEXT,
  machine_witnessable INTEGER NOT NULL,
  notes TEXT,
  FOREIGN KEY (source_id) REFERENCES sources(source_id)
);

CREATE TABLE thin_set_profiles_v19 (
  profile_id TEXT PRIMARY KEY,
  parameter_space TEXT NOT NULL,
  bad_polynomials_json TEXT NOT NULL,
  polynomial_count INTEGER NOT NULL,
  degree_sum INTEGER NOT NULL,
  thin_set_contract TEXT NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE torsion_control_points(
 curve_id TEXT NOT NULL, multiple_n INTEGER NOT NULL, x TEXT, y TEXT,
 is_identity INTEGER NOT NULL, point_on_curve INTEGER NOT NULL,
 PRIMARY KEY(curve_id,multiple_n));

CREATE TABLE trace_basis_certificates_v13 (
  stage_id TEXT PRIMARY KEY,
  basis_json TEXT NOT NULL,
  gram_matrix_json TEXT NOT NULL,
  gram_determinant INTEGER NOT NULL,
  gram_determinant_modulus INTEGER NOT NULL,
  determinant_is_unit INTEGER NOT NULL,
  quotient_rank INTEGER NOT NULL,
  coordinate_table_json TEXT NOT NULL,
  pass INTEGER NOT NULL,
  FOREIGN KEY (stage_id) REFERENCES pseudocharacter_stages_v13(stage_id)
);

CREATE TABLE transvection_generation_certificates_v18 (
  residual_prime INTEGER PRIMARY KEY,
  expected_sl2_order INTEGER NOT NULL,
  generated_sl2_order INTEGER NOT NULL,
  elementary_generation_pass INTEGER NOT NULL,
  determinant_surjective INTEGER NOT NULL,
  expected_gl2_order INTEGER NOT NULL,
  gl2_conclusion INTEGER NOT NULL
);

CREATE TABLE tw_arithmetic_attachment_frontier_v11 (
  frontier_id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  statement TEXT NOT NULL,
  status TEXT NOT NULL,
  source_id TEXT NOT NULL,
  exact_missing_adapter TEXT NOT NULL,
  load_bearing INTEGER NOT NULL
);

CREATE TABLE tw_freeness_obligations_v12 (
  obligation_id TEXT PRIMARY KEY,
  stage_order INTEGER NOT NULL,
  title TEXT NOT NULL,
  statement TEXT NOT NULL,
  status TEXT NOT NULL,
  witness_table TEXT,
  source_id TEXT,
  load_bearing INTEGER NOT NULL,
  exact_frontier TEXT NOT NULL
);

CREATE TABLE tw_freeness_parent_audit_v12 (
  edge_id TEXT PRIMARY KEY,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  algebraic_topological_compiler_internalized INTEGER NOT NULL,
  rank_one_hecke_input_internalized INTEGER NOT NULL,
  parent_removed INTEGER NOT NULL,
  child_import_count INTEGER NOT NULL,
  status TEXT NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE tw_limit_certificates_v11 (
  system_id TEXT PRIMARY KEY,
  stage_count INTEGER NOT NULL,
  all_truncations_pass INTEGER NOT NULL,
  diagonal_selection_pass INTEGER NOT NULL,
  inverse_limit_ring TEXT NOT NULL,
  power_series_ring TEXT NOT NULL,
  forward_map_json TEXT NOT NULL,
  inverse_map_json TEXT NOT NULL,
  kernel_zero INTEGER NOT NULL,
  free_rank_over_source INTEGER NOT NULL,
  free_rank_over_patched_ring INTEGER NOT NULL,
  augmentation_ideal_json TEXT NOT NULL,
  regular_sequence INTEGER NOT NULL,
  koszul_h1_dimension INTEGER NOT NULL,
  koszul_h2_dimension INTEGER NOT NULL,
  base_ring TEXT NOT NULL,
  r_equals_t INTEGER NOT NULL,
  complete_intersection INTEGER NOT NULL,
  module_free INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE tw_patching_compiler_runs_v11 (
  run_id TEXT PRIMARY KEY,
  system_id TEXT NOT NULL,
  contract_id TEXT NOT NULL,
  stage_contracts_pass INTEGER NOT NULL,
  ring_laws_pass INTEGER NOT NULL,
  finite_freeness_pass INTEGER NOT NULL,
  truncation_pass INTEGER NOT NULL,
  cardinality_bound_pass INTEGER NOT NULL,
  diagonal_selection_pass INTEGER NOT NULL,
  inverse_limit_pass INTEGER NOT NULL,
  kernel_dimension_pass INTEGER NOT NULL,
  regular_sequence_pass INTEGER NOT NULL,
  descent_pass INTEGER NOT NULL,
  compiler_accept INTEGER NOT NULL,
  conclusion_json TEXT NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE tw_patching_contracts_v11 (
  contract_id TEXT PRIMARY KEY,
  coefficient_field TEXT NOT NULL,
  variable_count INTEGER NOT NULL,
  source_ring TEXT NOT NULL,
  deformation_ring TEXT NOT NULL,
  hypotheses_json TEXT NOT NULL,
  conclusions_json TEXT NOT NULL,
  scope TEXT NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE tw_patching_counterfactuals_v11 (
  test_id TEXT PRIMARY KEY,
  violated_hypothesis TEXT NOT NULL,
  stage_contracts_pass INTEGER NOT NULL,
  finite_freeness_pass INTEGER NOT NULL,
  truncation_pass INTEGER NOT NULL,
  generator_bound_pass INTEGER NOT NULL,
  dimension_pass INTEGER NOT NULL,
  regular_sequence_pass INTEGER NOT NULL,
  compiler_accept INTEGER NOT NULL,
  expected_accept INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  interpretation TEXT NOT NULL
);

CREATE TABLE tw_patching_edge_audit_v11 (
  edge_id TEXT PRIMARY KEY,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  algebraic_patching_internalized INTEGER NOT NULL,
  arithmetic_stage_freeness_internalized INTEGER NOT NULL,
  arithmetic_stage_compatibility_internalized INTEGER NOT NULL,
  parent_removed_from_active_import_surface INTEGER NOT NULL,
  child_import_count INTEGER NOT NULL,
  main_trace_parent_derived INTEGER NOT NULL,
  status TEXT NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE tw_patching_obligations_v11 (
  obligation_id TEXT PRIMARY KEY,
  stage_order INTEGER NOT NULL,
  title TEXT NOT NULL,
  statement TEXT NOT NULL,
  status TEXT NOT NULL,
  witness_table TEXT,
  source_id TEXT,
  load_bearing INTEGER NOT NULL,
  exact_frontier TEXT NOT NULL
);

CREATE TABLE tw_prime_parent_audit_v20 (
  edge_id TEXT PRIMARY KEY,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  finite_quotient_selection_internalized INTEGER NOT NULL,
  analytic_chebotarev_reused INTEGER NOT NULL,
  parent_removed INTEGER NOT NULL,
  new_child_import_count INTEGER NOT NULL,
  theorem_content_fully_internalized_relative_to_existing_chebotarev INTEGER NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE tw_selection_contracts_v20 (
  contract_id TEXT PRIMARY KEY,
  residual_prime INTEGER NOT NULL,
  precision_symbol TEXT NOT NULL,
  dual_selmer_dimension INTEGER NOT NULL,
  cyclotomic_coordinate TEXT NOT NULL,
  residual_eigenvalues_json TEXT NOT NULL,
  eigenvalues_distinct INTEGER NOT NULL,
  determinant_one INTEGER NOT NULL,
  evaluation_vectors_json TEXT NOT NULL,
  evaluation_rank INTEGER NOT NULL,
  finite_quotient_constructed INTEGER NOT NULL,
  analytic_chebotarev_reused INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE tw_selection_runs_v20 (
  run_id TEXT PRIMARY KEY,
  residual_prime INTEGER NOT NULL,
  precision_n INTEGER NOT NULL,
  dual_selmer_dimension INTEGER NOT NULL,
  selected_primes_json TEXT NOT NULL,
  all_q_congruent_one INTEGER NOT NULL,
  all_split_distinct INTEGER NOT NULL,
  evaluation_rank INTEGER NOT NULL,
  dual_selmer_killed INTEGER NOT NULL,
  parent_theorem_derived INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE tw_selection_summary_v10 (
  residual_prime INTEGER NOT NULL,
  power_n INTEGER NOT NULL,
  witnessed_prime_count INTEGER NOT NULL,
  all_q_congruence_pass INTEGER NOT NULL,
  all_split_distinct_pass INTEGER NOT NULL,
  finite_search_status TEXT NOT NULL,
  universal_existence_status TEXT NOT NULL,
  PRIMARY KEY (residual_prime,power_n)
);

CREATE TABLE tw_stage_algebras_v11 (
  stage_id TEXT PRIMARY KEY,
  system_id TEXT NOT NULL,
  prime_p INTEGER NOT NULL,
  stage_n INTEGER NOT NULL,
  q_power INTEGER NOT NULL,
  group_ring_presentation TEXT NOT NULL,
  stage_algebra_presentation TEXT NOT NULL,
  x_presentation TEXT NOT NULL,
  base_algebra_presentation TEXT NOT NULL,
  group_ring_dimension INTEGER NOT NULL,
  stage_dimension INTEGER NOT NULL,
  free_rank_over_group_ring INTEGER NOT NULL,
  generator_count INTEGER NOT NULL,
  cardinality_log_p INTEGER NOT NULL,
  tw_bound_log_p INTEGER NOT NULL,
  frobenius_kernel_match INTEGER NOT NULL,
  augmentation_quotient_pass INTEGER NOT NULL,
  stage_contract_pass INTEGER NOT NULL,
  fingerprint TEXT NOT NULL
);

CREATE TABLE tw_stage_ring_checks_v11 (
  check_id TEXT PRIMARY KEY,
  stage_id TEXT NOT NULL,
  mode TEXT NOT NULL,
  basis_size INTEGER NOT NULL,
  tested_triples INTEGER NOT NULL,
  identity_failures INTEGER NOT NULL,
  commutativity_failures INTEGER NOT NULL,
  associativity_failures INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE tw_truncation_certificates_v11 (
  truncation_id TEXT PRIMARY KEY,
  system_id TEXT NOT NULL,
  source_stage INTEGER NOT NULL,
  target_stage INTEGER NOT NULL,
  source_q INTEGER NOT NULL,
  target_q INTEGER NOT NULL,
  multiplicative INTEGER NOT NULL,
  augmentation_compatible INTEGER NOT NULL,
  module_compatible INTEGER NOT NULL,
  surjective INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE twisted_x5_geometry(
 witness_id TEXT PRIMARY KEY, base_level INTEGER NOT NULL, component_genus INTEGER NOT NULL,
 rational_base_point INTEGER NOT NULL, parametrizes_shared_torsion INTEGER NOT NULL,
 theorem_status TEXT NOT NULL, source_id TEXT NOT NULL, notes TEXT);

CREATE TABLE twisted_x5_profiles_v10 (
  profile_id TEXT PRIMARY KEY,
  genus INTEGER NOT NULL,
  rational_point_present INTEGER NOT NULL,
  parameter_space TEXT NOT NULL,
  local_conditions_json TEXT NOT NULL,
  thin_set_avoidance_status TEXT NOT NULL,
  chebotarev_status TEXT NOT NULL,
  selected_curve_status TEXT NOT NULL,
  source_id TEXT
);

CREATE TABLE weight2_eigenpacket_projection_v18 (
  certificate_id TEXT PRIMARY KEY,
  residual_prime INTEGER NOT NULL,
  ambient_dimension INTEGER NOT NULL,
  commuting_operator_count INTEGER NOT NULL,
  residual_packet_dimension INTEGER NOT NULL,
  characteristic_zero_packet_present INTEGER NOT NULL,
  hecke_eigenvalues_preserved INTEGER NOT NULL,
  pass INTEGER NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE weight_change_obligations_v18 (
  obligation_id TEXT PRIMARY KEY,
  stage_order INTEGER NOT NULL,
  title TEXT NOT NULL,
  statement TEXT NOT NULL,
  status TEXT NOT NULL,
  witness_table TEXT,
  source_id TEXT,
  exact_frontier TEXT NOT NULL
);

CREATE TABLE weight_change_parent_audit_v18 (
  edge_id TEXT PRIMARY KEY,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  qexp_compiler_internalized INTEGER NOT NULL,
  eigenpacket_compiler_internalized INTEGER NOT NULL,
  parent_removed INTEGER NOT NULL,
  child_import_count INTEGER NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE weight_change_parent_audit_v20 (
  edge_id TEXT PRIMARY KEY,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  explicit_theta_internalized INTEGER NOT NULL,
  qexp_congruence_internalized INTEGER NOT NULL,
  eigenpacket_reuse INTEGER NOT NULL,
  parent_removed INTEGER NOT NULL,
  child_import_count INTEGER NOT NULL,
  theorem_content_fully_internalized_for_scope INTEGER NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE weight_change_product_certificates_v20 (
  certificate_id TEXT PRIMARY KEY,
  residual_prime INTEGER NOT NULL,
  coefficient_count INTEGER NOT NULL,
  source_coefficients_json TEXT NOT NULL,
  theta_coefficients_json TEXT NOT NULL,
  product_coefficients_json TEXT NOT NULL,
  all_differences_divisible_by_3 INTEGER NOT NULL,
  source_character TEXT NOT NULL,
  theta_character TEXT NOT NULL,
  product_character TEXT NOT NULL,
  source_weight INTEGER NOT NULL,
  theta_weight INTEGER NOT NULL,
  product_weight INTEGER NOT NULL,
  eigenpacket_compiler_pass INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE witness_contracts(contract_id TEXT PRIMARY KEY,function_name TEXT,input_schema_json TEXT,output_schema_json TEXT,certificate_schema_json TEXT,cache_key_formula TEXT,deterministic INTEGER,replayable INTEGER,trust_tier TEXT,protects_loop TEXT);

CREATE TABLE x015_descent_candidates_v18 (
  curve_id TEXT NOT NULL,
  isogenous_side TEXT NOT NULL,
  candidate_squareclass INTEGER NOT NULL,
  quartic_a INTEGER NOT NULL,
  quartic_b INTEGER NOT NULL,
  represented_by_point INTEGER NOT NULL,
  survives_all_local_tests INTEGER NOT NULL,
  PRIMARY KEY (curve_id,isogenous_side,candidate_squareclass)
);

CREATE TABLE x015_local_obstructions_v18 (
  obstruction_id TEXT PRIMARY KEY,
  isogenous_side TEXT NOT NULL,
  candidate_squareclass INTEGER NOT NULL,
  place TEXT NOT NULL,
  modulus INTEGER,
  primitive_solution_count INTEGER,
  obstruction_present INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE x015_parent_audit_v18 (
  edge_id TEXT PRIMARY KEY,
  previous_status TEXT NOT NULL,
  current_status TEXT NOT NULL,
  descent_internalized INTEGER NOT NULL,
  point_classification_internalized INTEGER NOT NULL,
  semistability_filter_internalized INTEGER NOT NULL,
  parent_removed INTEGER NOT NULL,
  child_import_count INTEGER NOT NULL,
  next_target TEXT NOT NULL
);

CREATE TABLE x015_rank_certificates_v18 (
  certificate_id TEXT PRIMARY KEY,
  alpha_image_size INTEGER NOT NULL,
  dual_alpha_image_size INTEGER NOT NULL,
  rank INTEGER NOT NULL,
  reduction_primes_json TEXT NOT NULL,
  reduction_orders_json TEXT NOT NULL,
  torsion_order_bound INTEGER NOT NULL,
  rational_points_found INTEGER NOT NULL,
  all_points_accounted_for INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE x015_rational_points_v18 (
  point_id TEXT PRIMARY KEY,
  x_coordinate TEXT,
  y_coordinate TEXT,
  group_coordinates TEXT NOT NULL,
  point_order INTEGER NOT NULL,
  point_type TEXT NOT NULL,
  associated_curve_conductor INTEGER,
  semistable_associated_curve INTEGER,
  pass INTEGER NOT NULL
);

CREATE TABLE x015_semistability_profiles_v18 (
  profile_id TEXT PRIMARY KEY,
  rational_point_count INTEGER NOT NULL,
  cusp_count INTEGER NOT NULL,
  noncuspidal_count INTEGER NOT NULL,
  noncuspidal_conductor INTEGER NOT NULL,
  conductor_squarefree INTEGER NOT NULL,
  semistable_non_cuspidal_count INTEGER NOT NULL,
  mod5_irreducibility_conclusion INTEGER NOT NULL,
  pass INTEGER NOT NULL
);

CREATE TABLE x0_15_obstruction(
 point_id TEXT PRIMARY KEY, point_class TEXT NOT NULL, semistable_at_3_and_5 INTEGER NOT NULL,
 classification_status TEXT NOT NULL, source_id TEXT NOT NULL, notes TEXT);

CREATE VIEW v10_active_import_surface AS
SELECT * FROM import_surface WHERE load_bearing=1 ORDER BY edge_id;

CREATE VIEW v10_invariant_health AS
SELECT
  tier,
  status,
  COUNT(*) AS check_count,
  SUM(pass_count) AS pass_rows,
  SUM(fail_count) AS fail_rows,
  SUM(universe_count) AS universe_rows
FROM invariant_checks
GROUP BY tier,status
ORDER BY tier,status;

CREATE VIEW v10_parent_replacements AS
SELECT * FROM omnibus_parent_replacements_v10 ORDER BY parent_id;

CREATE VIEW v11_invariant_health AS
SELECT tier,status,COUNT(*) check_count,
       SUM(pass_count) pass_rows,
       SUM(fail_count) fail_rows,
       SUM(universe_count) universe_rows
FROM invariant_checks
GROUP BY tier,status
ORDER BY tier,status;

CREATE VIEW v11_patching_edge_audit AS
SELECT * FROM tw_patching_edge_audit_v11;

CREATE VIEW v11_valid_compiler_runs AS
SELECT * FROM tw_patching_compiler_runs_v11
WHERE compiler_accept=1
ORDER BY run_id;

CREATE VIEW v12_active_import_surface AS
SELECT * FROM import_surface WHERE load_bearing=1 ORDER BY edge_id;

CREATE VIEW v12_edge_reductions AS
SELECT * FROM edge_reduction_audit_v12 ORDER BY edge_id;

CREATE VIEW v12_invariant_health AS
SELECT tier,status,COUNT(*) check_count,
       SUM(pass_count) pass_rows,
       SUM(fail_count) fail_rows,
       SUM(universe_count) universe_rows
FROM invariant_checks
GROUP BY tier,status
ORDER BY tier,status;

CREATE VIEW v13_active_import_surface AS
SELECT * FROM import_surface WHERE load_bearing=1 ORDER BY edge_id;

CREATE VIEW v13_edge_audit AS
SELECT * FROM hecke_galois_parent_audit_v13;

CREATE VIEW v13_invariant_health AS
SELECT tier,status,COUNT(*) check_count,
       SUM(pass_count) pass_rows,
       SUM(fail_count) fail_rows,
       SUM(universe_count) universe_rows
FROM invariant_checks
GROUP BY tier,status
ORDER BY tier,status;

CREATE VIEW v14_active_import_surface AS
SELECT * FROM import_surface WHERE load_bearing=1 ORDER BY edge_id;

CREATE VIEW v14_edge_audit AS
SELECT edge_id,previous_status,current_status,parent_removed,child_import_count,status,next_target
FROM modular_pseudocharacter_parent_audit_v14
UNION ALL
SELECT edge_id,previous_status,current_status,parent_removed,child_import_count,status,next_target
FROM local_global_parent_audit_v14;

CREATE VIEW v14_invariant_health AS
SELECT tier,status,COUNT(*) check_count,SUM(pass_count) pass_rows,
SUM(fail_count) fail_rows,SUM(universe_count) universe_rows
FROM invariant_checks GROUP BY tier,status ORDER BY tier,status;

CREATE VIEW v15_active_import_surface AS SELECT * FROM import_surface WHERE load_bearing=1 ORDER BY edge_id;

CREATE VIEW v15_edge_audit AS SELECT * FROM parent_edge_audit_v15 ORDER BY edge_id;

CREATE VIEW v15_invariant_health AS SELECT tier,status,COUNT(*) check_count,SUM(pass_count) pass_rows,SUM(fail_count) fail_rows,SUM(universe_count) universe_rows FROM invariant_checks GROUP BY tier,status ORDER BY tier,status;

CREATE VIEW v16_active_import_surface AS
SELECT * FROM import_surface WHERE load_bearing=1 ORDER BY edge_id;

CREATE VIEW v16_invariant_health AS
SELECT tier,status,COUNT(*) check_count,
       SUM(pass_count) pass_rows,
       SUM(fail_count) fail_rows,
       SUM(universe_count) universe_rows
FROM invariant_checks
GROUP BY tier,status
ORDER BY tier,status;

CREATE VIEW v16_multiplicity_audit AS
SELECT * FROM multiplicity_parent_audit_v16;

CREATE VIEW v17_active_import_surface AS
SELECT * FROM import_surface WHERE load_bearing=1 ORDER BY edge_id;

CREATE VIEW v17_five_edge_audit AS
SELECT * FROM five_edge_audit_v17 ORDER BY edge_order;

CREATE VIEW v17_invariant_health AS
SELECT tier,status,COUNT(*) check_count,
       SUM(pass_count) pass_rows,
       SUM(fail_count) fail_rows,
       SUM(universe_count) universe_rows
FROM invariant_checks
GROUP BY tier,status
ORDER BY tier,status;

CREATE VIEW v18_active_import_surface AS
SELECT * FROM import_surface WHERE load_bearing=1 ORDER BY edge_id;

CREATE VIEW v18_invariant_health AS
SELECT tier,status,COUNT(*) check_count,
       SUM(pass_count) pass_rows,
       SUM(fail_count) fail_rows,
       SUM(universe_count) universe_rows
FROM invariant_checks
GROUP BY tier,status
ORDER BY tier,status;

CREATE VIEW v18_second_five_edge_audit AS
SELECT * FROM second_five_edge_audit_v18 ORDER BY edge_order;

CREATE VIEW v18_ten_edge_batch_audit AS
SELECT * FROM ten_edge_batch_audit_v18;

CREATE VIEW v19_active_import_surface AS
SELECT * FROM import_surface WHERE load_bearing=1 ORDER BY edge_id;

CREATE VIEW v19_five_edge_audit AS
SELECT * FROM five_edge_audit_v19 ORDER BY edge_order;

CREATE VIEW v19_invariant_health AS
SELECT tier,status,COUNT(*) check_count,
       SUM(pass_count) pass_rows,
       SUM(fail_count) fail_rows,
       SUM(universe_count) universe_rows
FROM invariant_checks
GROUP BY tier,status
ORDER BY tier,status;

CREATE VIEW v1_import_surface AS
SELECT
  COUNT(*) AS imported_edge_count,
  SUM(load_bearing) AS load_bearing_count,
  SUM(proof_internalized) AS internalized_count,
  SUM(antecedent_geometry_witnessed) AS antecedent_geometry_witnessed_count
FROM import_surface;

CREATE VIEW v1_invariant_health AS
SELECT
  tier,
  status,
  COUNT(*) AS check_count,
  SUM(pass_count) AS total_passes,
  SUM(fail_count) AS total_failures,
  SUM(universe_count) AS total_universe
FROM invariant_checks
GROUP BY tier, status
ORDER BY tier, status;

CREATE VIEW v1_level_lowering_terminal AS
SELECT
  profile_id,
  MAX(step_no) AS final_step,
  MAX(CASE WHEN terminal_level_2=1 THEN 1 ELSE 0 END) AS reaches_level_2
FROM level_lowering_steps
GROUP BY profile_id;

CREATE VIEW v1_modular_phase_boundary AS
SELECT *
FROM modular_dimension_phase
WHERE first_positive_dimension=1 OR level_n=2
ORDER BY level_n;

CREATE VIEW v20_active_import_surface AS
SELECT * FROM import_surface WHERE load_bearing=1 ORDER BY edge_id;

CREATE VIEW v20_five_import_audit AS
SELECT * FROM five_import_audit_v20 ORDER BY edge_order;

CREATE VIEW v20_invariant_health AS
SELECT tier,status,COUNT(*) check_count,
       SUM(pass_count) pass_rows,
       SUM(fail_count) fail_rows,
       SUM(universe_count) universe_rows
FROM invariant_checks
GROUP BY tier,status
ORDER BY tier,status;

CREATE VIEW v21_active_import_surface AS
SELECT * FROM import_surface WHERE load_bearing=1 ORDER BY edge_id;

CREATE VIEW v21_foundation_frontier AS
SELECT * FROM foundation_kernels_v21 ORDER BY kernel_order;

CREATE VIEW v21_invariant_health AS
SELECT tier,status,COUNT(*) check_count,
       SUM(pass_count) pass_rows,
       SUM(fail_count) fail_rows,
       SUM(universe_count) universe_rows
FROM invariant_checks
GROUP BY tier,status
ORDER BY tier,status;

CREATE VIEW v21_nine_parent_audit AS
SELECT * FROM nine_parent_audit_v21 ORDER BY edge_order;

CREATE VIEW v2_branch_health AS
 SELECT branch_name,COUNT(*) steps,SUM(witnessed) witnessed_steps,
        SUM(imported) imported_steps,MAX(branch_complete) branch_complete
 FROM residual_modularity_steps GROUP BY branch_name ORDER BY branch_name;

CREATE VIEW v2_import_surface AS
 SELECT COUNT(*) imported_edge_count,SUM(load_bearing) load_bearing_count,
        SUM(proof_internalized) internalized_count,
        SUM(antecedent_geometry_witnessed) antecedent_geometry_witnessed_count
 FROM import_surface;

CREATE VIEW v2_invariant_health AS
 SELECT tier,status,COUNT(*) check_count,SUM(pass_count) total_passes,
        SUM(fail_count) total_failures,SUM(universe_count) total_universe
 FROM invariant_checks GROUP BY tier,status ORDER BY tier,status;

CREATE VIEW v3_invariant_health AS SELECT tier,status,COUNT(*) check_count,SUM(pass_count) total_passes,SUM(fail_count) total_failures,SUM(universe_count) total_universe FROM invariant_checks GROUP BY tier,status ORDER BY tier,status;

CREATE VIEW v3_proof_frontier AS SELECT status,COUNT(*) obligation_count,SUM(load_bearing) load_bearing_count FROM level_lowering_obligations GROUP BY status;

CREATE VIEW v4_invariant_health AS
SELECT tier,status,COUNT(*) AS check_count,
       SUM(pass_count) AS pass_rows,
       SUM(fail_count) AS fail_rows,
       SUM(universe_count) AS universe_rows
FROM invariant_checks
GROUP BY tier,status
ORDER BY tier,status;

CREATE VIEW v4_target_frontier AS
SELECT * FROM target_frontier_audit ORDER BY edge_id;

CREATE VIEW v5_edge_frontier AS
SELECT * FROM edge_reduction_audit_v5 ORDER BY edge_id;

CREATE VIEW v5_invariant_health AS
SELECT tier,status,COUNT(*) check_count,
       SUM(pass_count) pass_rows,
       SUM(fail_count) fail_rows,
       SUM(universe_count) universe_rows
FROM invariant_checks
GROUP BY tier,status
ORDER BY tier,status;

CREATE VIEW v5_lowering_certificates AS
SELECT * FROM lower_level_eigenform_certificates ORDER BY certificate_id;

CREATE VIEW v6_edge_closures AS
SELECT * FROM edge_closure_audit_v6 ORDER BY edge_id;

CREATE VIEW v6_invariant_health AS
SELECT tier,status,COUNT(*) AS check_count,
       SUM(pass_count) AS pass_rows,
       SUM(fail_count) AS fail_rows,
       SUM(universe_count) AS universe_rows
FROM invariant_checks
GROUP BY tier,status
ORDER BY tier,status;

CREATE VIEW v6_obstruction_certificates AS
SELECT * FROM specialization_obstruction_certificates_v6 ORDER BY obstruction_id;

CREATE VIEW v7_edge_closures AS
SELECT * FROM edge_closure_audit_v7 ORDER BY edge_id;

CREATE VIEW v7_ihara_phase AS
SELECT base_level_n,removed_prime_q,residual_prime,combined_rank,
       target_double_dimension,cokernel_dimension,surjective,
       non_eisenstein_gate,status
FROM degeneracy_map_certificates_v7
ORDER BY removed_prime_q,residual_prime;

CREATE VIEW v7_invariant_health AS
SELECT tier,status,COUNT(*) AS check_count,
       SUM(pass_count) AS pass_rows,
       SUM(fail_count) AS fail_rows,
       SUM(universe_count) AS universe_rows
FROM invariant_checks
GROUP BY tier,status
ORDER BY tier,status;

CREATE VIEW v8_edge_closures AS
SELECT * FROM edge_closure_audit_v8 ORDER BY edge_id;

CREATE VIEW v8_invariant_health AS
SELECT tier,status,COUNT(*) AS check_count,
       SUM(pass_count) AS pass_rows,
       SUM(fail_count) AS fail_rows,
       SUM(universe_count) AS universe_rows
FROM invariant_checks
GROUP BY tier,status
ORDER BY tier,status;

CREATE VIEW v8_packet_dimensions AS
SELECT packet_id,level_n,residual_prime,full_dimension,
       plus_dimension,minus_dimension,status
FROM hecke_packet_certificates_v8
ORDER BY packet_id;

CREATE VIEW v9_edge_closures AS
SELECT * FROM edge_closure_audit_v9 ORDER BY edge_id;

CREATE VIEW v9_final_work_schedule AS
SELECT * FROM final_work_schedule_v9 ORDER BY sequence_no;

CREATE VIEW v9_invariant_health AS
SELECT tier,status,COUNT(*) AS check_count,
       SUM(pass_count) AS pass_rows,
       SUM(fail_count) AS fail_rows,
       SUM(universe_count) AS universe_rows
FROM invariant_checks
GROUP BY tier,status
ORDER BY tier,status;

CREATE VIEW v_frey_sample_summary AS
SELECT
  sample_id, a, b, p, gcd_ab, opposite_parity,
  c_power_is_perfect_pth,
  discriminant, c4, c6,
  invariant_identity_pass
FROM frey_samples;

CREATE VIEW v_invariant_health AS
SELECT
  tier,
  status,
  COUNT(*) AS check_count,
  SUM(pass_count) AS total_passes,
  SUM(fail_count) AS total_failures,
  SUM(universe_count) AS total_universe
FROM invariant_checks
GROUP BY tier, status
ORDER BY tier, status;

CREATE VIEW v_local_geometry AS
SELECT
  l.sample_id, f.a, f.b, f.p, l.prime_q,
  l.divides_a, l.divides_b, l.divides_c_power_sum,
  l.v_discriminant, l.v_c4,
  l.reduction_type_away_from_2,
  l.conductor_exponent_away_from_2,
  l.valuation_divisible_by_p_observed,
  l.valuation_divisible_by_p_under_flt_condition,
  l.check_pass
FROM local_prime_witnesses l
JOIN frey_samples f USING (sample_id);

CREATE VIEW v_proof_frontier AS
SELECT
  node_kind,
  status,
  COUNT(*) AS node_count,
  SUM(machine_witnessable) AS machine_witnessable_count
FROM theorem_nodes
GROUP BY node_kind, status
ORDER BY node_kind, status;